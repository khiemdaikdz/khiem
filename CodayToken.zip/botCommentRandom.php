<?php

if(!$_SESSION['id']){ mbalek('index.php'); exit; }

print '<div class="wrapper wrapper-content animated fadeInRight">

      <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Bot Comment Tự Chọn</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
 
 


            ';
?>

<script>
var seconds = ;
function secondPassed() {
    var minutes = Math.round((seconds - 30)/60);
    var remainingSeconds = seconds % 60;
    if (remainingSeconds < 10) {
        remainingSeconds = "0" + remainingSeconds;  
    }
    document.getElementById('countdown').innerHTML = "<h3>--> Next Submit: Wait  " + minutes + ":" + remainingSeconds + "  Seconds <--</h3>";
    if (seconds <= 0) {
        clearInterval(countdownTimer);
        document.getElementById('countdown').innerHTML = "<h3>--> Next Submit: READY....! <--</h3>";
    } else {
        seconds--;
    }
}
 
var countdownTimer = setInterval('secondPassed()', 1000);
</script>
<script type="text/javascript">
function done()
	{
	$("#bodyupcmt").hide();
	$("#thongbao").show();
	}
</script>

<div class="panel-heading ui-draggable-handle">
                        <h3 class="panel-title">Bot Cmt Tùy Nội Dung:</h3>
                    </div>
            <div class="tab-content">
              <div class="active tab-pane" id="menu">
                <!-- Post -->
                <div class="post">
<div class="alert alert-info" role="alert">
                                <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                <strong><i class="fa fa-info"></i> Thông báo:</strong> Để sử dụng chức năng này một cách tốt nhất bạn nên lấy token API. Trân Thành cảm Ơn
                            </div>


	<div id="bodyupcmt" class="panel-body">
		<form action="/cmtrd.php" method="post">	
<div class="tab-content">

 <label>        Access Token (1 Token = 1 Line)</label>

<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span><textarea rows="5" type="text" name="access_token" class="form-control" value="" placeholder="Nhập Access Token Vào Đây...!!!" autofocus="" required=""><? echo $_SESSION['access_token'];?></textarea>	



	</div>

  <label>        Tắt / Bật Dịch Vụ </label></br>

<td>
												<input type="radio" name="tatmo" value="1" /> <label>        Tắt </label>
											</td>
											<td>
												<input type="radio" name="tatmo" value="0" /> <label>        Bật</label>
											</td>
											
											</br>

	

                                            <label>        Nhập Nội Dung Comment</label>



<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-comment"></span></span><textarea rows="5" type="text" name="noidung" class="form-control" value="Hay" placeholder="Nhập Nội Dung Vào Đây!" autofocus="" required=""></textarea>
			
</div><br>
<span class="input-group-btn">
	<center>	<button type="submit" name="submit" onClick="done()" class="btn btn-primary">
						<span id="btn-click">
						<span class="glyphicon glyphicon-transfer"></span> Gửi yêu cầu
						</span>
				</button>			</center>			</span>
		</div>			

</form>
		</div>			

<div id="thongbao" style="display: none;"><div class="alert alert-danger">Trạng Thái: <span class="glyphicon glyphicon-refresh gly-animate"></span>  Đang Gửi Yêu Cầu...!
</font></div>

</section></section>
	
   
	<!-- ============================ End ============================ -->
    </div>
   </div>
</div>
</div>