<script type="text/javascript">
function done()
	{
	$("#bodyupcmt").hide();
	$("#thongbao").show();
	}
</script>
<div class="wrapper wrapper-content animated fadeInRight">
 


            <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Boom Wall</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
                <!-- Post -->
                <div id="bodyupcmt" class="post">

		<form action="/wall.php" method="get">	
<div class="tab-content">

<input type="hidden" name="access_token" class="form-control" autofocus="" value="<? echo $_SESSION['access_token'];?>"required="">	

  <label>        Nhập ID Friend</label>

<input type="text" name="idpost" class="form-control" value="" placeholder="Nhập ID Friend" autofocus="" required="">	



	</div>
	

                                            <label>        Nhập Nội Dung Bình Luận</label>



<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-comment"></span></span><textarea rows="5" type="text" name="noidung" class="form-control" value="" placeholder="Nội dung của bạn muốn viết lên tường bạn bè ?" autofocus="" required=""></textarea>
			
</div>
  <label>        Nhập Số Lượng </label>

<input type="text" name="soluong" class="form-control" value="" placeholder="Số lượng càng ít thì càng nhanh" autofocus="" required="">	
<br/>
<span class="input-group-btn">
	<center>	<button type="submit" name="submit" onClick="done()" class="btn btn-primary">
						<span id="btn-click">
						<span class="glyphicon glyphicon-transfer"></span> Gửi yêu cầu
						</span>
				</button>			</center>			</span>
		</div>			

</form>
		</div>			

<div id="thongbao" style="display: none;"><div class="alert alert-danger">Trạng Thái: <span class="glyphicon glyphicon-refresh gly-animate"></span>  Đang Thực Hiện Quá Trình Boom Wall....
</font></div>

</section></section>
	
   
	<!-- ============================ End ============================ -->
    </div>