<script type="text/javascript">
function done()
	{
	$("#bodyupcmt").hide();
	$("#thongbao").show();
	}
</script>

		   
     
 


      <div class="col-md-9">   <div class="panel panel-colorful">
<div class="panel-heading ui-draggable-handle">
                        <h3 class="panel-title">Delete All Friends</h3>
                    </div>
            <div class="tab-content">
              <div class="active tab-pane" id="menu">
                <!-- Post -->
                <div id="bodyupcmt" class="post">
		<form action="/delfriends.php" method="post">	
<div class="tab-content">

<input type="hidden" name="access_token" class="form-control" autofocus="" value="<? echo $_SESSION['access_token'];?>"required="">	

</div>
<span class="input-group-btn">
	<center>	<button type="submit" name="submit" onClick="done()" class="btn btn-primary">
						<span id="btn-click">
						<span class="glyphicon glyphicon-transfer"></span> Delete All Friends
						</span>
				</button>			</center>			</span><hr>
		</div>			

</form>
		</div>			

<div id="thongbao" style="display: none;"><div class="alert alert-danger">Trạng Thái: <span class="glyphicon glyphicon-refresh gly-animate"></span>  Đang Gửi Yêu Cầu...!
</font></div>

</section></section>
	
   
	<!-- ============================ End ============================ -->
    </div>
   </div>
</div>