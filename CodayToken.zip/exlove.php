<?php

if(!$_SESSION['id']){ mbalek('index.php'); exit; }

print '<div class="wrapper wrapper-content animated fadeInRight">

     
 
 


            ';
?>
<?php
$dem = mysql_result(mysql_query("select count(*) from `exlove` where `user_id`='".$_SESSION['id']."' "),0);
$tonguser = mysql_result(mysql_query("select count(*) from `exlove`"),0);
?>

<?php
if($dem == 0)
{
	$tinhtrang = 'Chưa được cài đặt';
} 
else
{
	$tinhtrang = 'Đã được cài đặt';
}
?>

<div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Bot Ex Love - Robot Tự Động Love  Vào Status Mới Nhất Của Bạn</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
            <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
                <!-- Post -->
                <div class="post">

         Trạng Thái: <b><?php echo $tinhtrang; ?></b>
<div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger progress-bar-striped" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
                  <span class="sr-only">60% Complete (warning)</span>
                </div>
              </div>
<center><b>Hiện tại có <?php echo $tonguser; ?> người dùng đang sử dụng chức năng này! </b></center></div>
<hr><form class="form-horizontal" method="post" action="?act=exlove"/><div align="center">
<?php
if($dem == 0)
{
echo '<input type="submit" name="install" value="Cài Đặt" class="btn btn-success"/>';
}
else
{
echo '<input type="submit" name="update" value="Cập Nhật" class="btn btn-success"/><hr><input type="submit" name="huy" value="Gở BOT" class="btn btn-danger"/>';
}
?></form>
</div>
</div></div></div></div></div></div></div></div>


<?
if($_POST['install'] && $_SESSION['id'])
{
	mysql_query("CREATE TABLE IF NOT EXISTS `exlove` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` varchar(32) NOT NULL,
      `name` varchar(32) NOT NULL,
      `access_token` varchar(255) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");
   $row = null;
   $result = mysql_query("
      SELECT
         *
      FROM
         exlove
      WHERE
         user_id = '" . mysql_real_escape_string($_SESSION['id']) . "'
   ");
   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);
      if(mysql_num_rows($result) > 100){
         mysql_query("
            DELETE FROM
               camxuc
            WHERE
               user_id='" . mysql_real_escape_string($_SESSION['id']) . "' AND
               id != '" . $row['id'] . "'
         ");
      }
   }
 
   if(!$row){
      mysql_query(
         "INSERT INTO 
            exlove
         SET
            `user_id` = '" . mysql_real_escape_string($_SESSION['id']) . "',
            `name` = '" . mysql_real_escape_string($_SESSION['name']) . "',
            `access_token` = '" . mysql_real_escape_string($_SESSION['access_token']) . "'
      ");
   } else {
      mysql_query(
         "UPDATE 
            exlove
         SET
            `access_token` = '" . mysql_real_escape_string($_SESSION['access_token']) . "'
         WHERE
            `id` = " . $row['id'] . "
      ");
   }
   
   ?>
   <meta http-equiv=refresh content="0; URL=?act=exlove&i=Cài đặt thành công">
   <?
}
if($_POST['huy'] && $_SESSION['id'])
{
mysql_query("
            DELETE FROM
               exlove
            WHERE
               user_id='" . mysql_real_escape_string($_SESSION['id']) . "' 
         ");
   ?>
   <meta http-equiv=refresh content="0; URL=?act=exlove&i=Hủy cài đặt thành công">
   <?
}
?>
<?
if($_POST['update'] && $_SESSION['id'])
{
	mysql_query("CREATE TABLE IF NOT EXISTS `exlove` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` varchar(32) NOT NULL,
      `name` varchar(32) NOT NULL,
      `access_token` varchar(255) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");
   $row = null;
   $result = mysql_query("
      SELECT
         *
      FROM
         exlove
      WHERE
         user_id = '" . mysql_real_escape_string($_SESSION['id']) . "'
   ");
   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);
      if(mysql_num_rows($result) > 100){
         mysql_query("
            DELETE FROM
               exlove
            WHERE
               user_id='" . mysql_real_escape_string($_SESSION['id']) . "' AND
               id != '" . $row['id'] . "'
         ");
      }
   }
 
   if(!$row){
      mysql_query(
         "INSERT INTO 
            exlove
         SET
            `user_id` = '" . mysql_real_escape_string($_SESSION['id']) . "',
            `name` = '" . mysql_real_escape_string($_SESSION['name']) . "',
            `access_token` = '" . mysql_real_escape_string($_SESSION['token']) . "'
      ");
   } else {
      mysql_query(
         "UPDATE 
            exlove
         SET
            `access_token` = '" . mysql_real_escape_string($_SESSION['token']) . "'
         WHERE
            `id` = " . $row['id'] . "
      ");
   }
   ?>
   <meta http-equiv=refresh content="0; URL=?act=exlove&i=cập nhật thành công">
   <?
}

 ?>