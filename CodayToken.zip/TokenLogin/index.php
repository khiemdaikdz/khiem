<?php
include 'head.php';
print'<div class="content-wrapper" style="min-height: 1126px;">
<section class="content-header">
<h1>
STARVIP.INFO
</h1>
</section>
<div class="pad margin no-print">
<div class="callout callout-info" style="margin-bottom: 0!important;">
<h4><i class="fa fa-info"></i> Thông báo:</h4>
Sau đây là hướng dẫn của chúng tôi.
</div>
</div>
 

 
<section class="content">

      <div class="row">
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header">
             

              <b><h3 class="box-title">Hướng Dẫn Lấy Token Full Quyền</h3><b><hr>
            </div>
            <div class="box-body pad table-responsive"><center>
Đâu Tiên Các Bạn <a href="view-source:https://goo.gl/QeNm3Q" target="_blank"><button type="button" class="btn btn-success btn-xs"> Vào Đây </button></a> Rồi Làm Theo Hướng Dẫn Sau.<br>
<b>Bước 1 :</b><br><img src="http://i.imgur.com/MAAyUIL.png"><br>
<b>Bước 2 :</b><br><img src="http://i.imgur.com/BgCnI3A.png"></center>

<h4><b>Hướng dẫn Video<b></h4>
<center><iframe width="560" height="315" src="https://www.youtube.com/embed/syhgOcOQlOQ" frameborder="0" allowfullscreen></iframe>
                                        </div></center>
</div></div></div>
</section>
</div></div></div>

     ';
	include'foot.php';
	?>