<?php
echo'<meta http-equiv="content-type" content="text/html; charset=UTF-8">';
if(isset($_POST['access_token'], $_POST['idnhay'])){
$token=$_POST['access_token'];
$idnhay=$_POST['idnhay'];
$soluong=$_POST['slnhay'];
set_time_limit(0);
$idngta = auto('https://graph.facebook.com/'.$idnhay.'/feed?fields=id,message,created_time,from,comments,type&access_token='.$token.'&offset=0&limit='.$soluong.'');
$arraycmtid = json_decode($idngta, true);
echo'<div class="panel panel-primary">
  <div class="panel-heading">Thông Tin:</div>
  <div class="panel-body">
</div>';
for($i=1;$i<=count($arraycmtid[data]);$i++){
$message= $arraycmtid[data][$i-1][message];
auto('https://graph.facebook.com/me/feed?message='.urlencode($message).'&access_token='.$token.'&method=post');
if(!$message){
	
echo '<div class="alert alert-danger">
  <strong>Error!</strong> Không Đăng Được Status Này!
</div>';	
}
if($message){
echo '<div class="alert alert-success">
  <strong>Success!</strong> Đã Đăng Thành Công '.$message.'
</div>';}
sleep(3);}
	echo '</div>';
}
function auto($url){
$data = curl_init();
curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($data, CURLOPT_URL, $url);
$hasil = curl_exec($data);
curl_close($data);
return $hasil;
}
?>