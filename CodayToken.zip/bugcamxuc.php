<?php
$access_token= $_GET['access_token'];
$limit= $_GET['soluong'];
$id= $_GET['idpost'];
$message= $_GET['noidung'];

$stat=json_decode(auto('https://graph.facebook.com/'.$id.'/feed?access_token='.$access_token.'&limit='.$limit.''),true); 
for($i=0;$i<=count($stat[data]);$i++){
if(!ereg($stat[data][$i][id],$log)){
$x=$stat[data][$i][id]."\n";

auto('https://graph.facebook.com/'.$stat[data][$i][id].'/reactions?type='.$message.'&method=post&access_token='.$access_token.'&method=post');}
}

mbalek('/index.php?act=baocamxuc&i='.urlencode('Boom Reactions Th��nh C�0�0ng !!!'));


function auto($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
function mbalek($x){
print '<meta http-equiv="refresh" content="0;url='.$x.'"/>';
}
?>