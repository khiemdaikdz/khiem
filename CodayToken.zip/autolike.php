<script type="text/javascript">
function done()
	{
	$("#bodyupcmt").hide();
	$("#thongbao").show();
	}
</script>



      <div class="col-md-12">   <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Auto Like</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
            <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
                <!-- Post -->
                <div id="bodyupcmt" class="post">

		<form action="/lenlike.php" method="POST">	

<input type="hidden" name="access_token" class="form-control" autofocus="" value="<? echo $_SESSION['access_token'];?>"required="">	


  <label>        Nhập ID Muốn Auto Like </label>
<?php
print'
<input type="text" name="uid" class="form-control" value="" placeholder="Profile ID đấy nhìn phía bên trái kìa..." autofocus="" required="">	
<br/>';
?>
<span class="input-group-btn">
	<center>	<button type="submit" name="submit" onClick="done()" class="btn btn-primary">
						<span id="btn-click">
						<span class="glyphicon glyphicon-transfer"></span> Auto Like
						</span>
				</button>			</center>			</span>
		</div>			

</form>
		</div>			

<div id="thongbao" style="display: none;"><div class="alert alert-danger">Trạng Thái: <span class="glyphicon glyphicon-refresh gly-animate"></span>  Đang Thực Hiện Quá Trình Auto Like ...!!!
</font></div>

</section></section>
	
   
	<!-- ============================ End ============================ -->
    </div>