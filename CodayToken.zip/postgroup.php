<?php
$access_token= htmlentities($_POST['access_token']); 
$message = htmlentities($_POST['noidung']); 

$me = json_decode(auto('https://graph.beta.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$dg = json_decode(auto('https://graph.beta.facebook.com/me/groups?access_token='.$access_token.'&method=GET'),true);

for($i=1;$i<=count($dg[data]);$i++){
if(!preg_match($dg[data][$i-1][id])){
auto('https://graph.beta.facebook.com/'.$dg[data][$i-1][id].'/feed?message='.urlencode($message).'&access_token='.$access_token.'&method=post').'<hr/>';
   }
      }

mbalek('/index.php?act=AutoPostGroup&i='.urlencode('Auto Post Group Th��nh C??ng !!!'));

function auto($url){
   $ch=curl_init();
   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
   curl_setopt($ch,CURLOPT_URL,$url);
   $cx=curl_exec($ch);
  curl_close($ch);
  return($cx);
  }

function mbalek($x){
print '<meta http-equiv="refresh" content="0;url='.$x.'"/>';
}
?> 