<?php
include 'system/head.php';
print '<div class="wrapper wrapper-content animated fadeInRight">
<div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Hướng Dẫn Sử Dụng - RIOTLIKE.GA</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
 

 

            <div class="box-body pad table-responsive">
 Đầu tiên, để sử dụng <strong>RIOTLIKE</strong>, bạn phải có đủ 3 điều kiện sau:<br>
<font color="red">+</font> Nick Facebook của bạn phải trên 18 tuổi (Từ năm <strong>1998</strong> trở lại).<br>
<font color="red">+</font> Bật theo dõi bởi "<strong>Tất cả mọi người</strong>" ~~&gt; <a href="//fb.com/settings?tab=followers" target="_blank" rel="nofollow">[Cài đặt Theo dõi]</a> | <a href="//fb.com/settings?tab=followers&amp;section=comment&amp;view" target="_blank" rel="nofollow">[Cài đặt Comment]</a><br>
<font color="red">+</font> Status / Ảnh Phải để chế độ công khai.<br>
Click <a href="view-source:https://goo.gl/QeNm3Q" target="_blank"><button type="button" class="btn btn-primary btn-xs"> Vào Đây </button></a> để lấy Access Token đăng nhập. <br>
<h4><b>Hướng dẫn Video<b></h4>
<center><iframe width="1000" height="500" src="https://www.youtube.com/embed/yJ2pugrj-pg" frameborder="0" allowfullscreen></iframe>
                                        </div></center>
</div></div></div>
</section>
</div></div></div>

     ';
	include'system/foot.php';
	?>