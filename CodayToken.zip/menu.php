<?php
error_reporting(0);
if($act){
if(
$act == 'botlike' ||
$act == 'botPoke' ||
$act == 'botSimSimi' ||
$act == 'autolike' ||
$act == 'BotCNN' ||
$act == 'autocmt' ||
$act == 'autoshare' ||
$act == 'bomComment' ||
$act == 'BotUpdateStt' ||
$act == 'autosub' ||
$act == 'exlike' ||
$act == 'exlove' ||
$act == 'cm' ||
$act == 'cm2' ||
$act == 'botcmtSV' ||
$act == 'AutoConfirm' ||
$act == 'botSttRandom' ||
$act == 'botReactions' ||
$act == 'bomLike' ||
$act == 'AutoPostGroup' ||
$act == 'AutoPostFr' ||
$act == 'AutoCopyStt' ||
$act == 'AutoPostPage' ||
$act == 'AutoPostStt' ||
$act == 'baocamxuc' ||
$act == 'DelStt' ||
$act == 'UnLikeFanpage' ||
$act == 'DeleteAllFriends' ||
$act == 'AutoAddFriend' ||
$act == 'botInBoxRandom' ||
$act == 'botInBox' ||
$act == 'botCommentRandom' ||
$act == 'bomWall' ){
include $act.'.php';
}


if($act == menu){
print '</div>';
botMenu();
}else{
//botMenu();
}
}else{
botMenu();
}
function botMenu(){
print '        <div class="wrapper wrapper-content animated fadeInRight">



                        <div class="widget-head-color-box navy-bg p-lg text-center">
                            <div class="m-b-md">
                            <h2 class="font-bold no-margins">
                                '.$_SESSION['name'].'                            </h2>
                                <small>Chào Mừng Đến Với VUTIENDUC.NET.</small>
                            </div>
                            <img class="img-circle" width="150" height="150" src="https://graph.facebook.com/'.$_SESSION['id'].'/picture?type=large" alt="VUTIENDUC.NET">
                            <div> <br>                    
                                <span><a class="btn btn-danger btn-sm"> '.$_SESSION['id'].' </span></a> |
                                <span><a href="https://facebook.com/'.$_SESSION['id'].'" class="btn btn-success btn-sm">'.$_SESSION['name'].'</a></span> |
                                <span><a href="https://facebook.com/'.$_SESSION['id'].'" class="btn btn-warning btn-sm">'.$_SESSION['gender'].'</a></span>
                            </div>
                        </div>
                        <div class="widget-text-box"><center>
                            <h4 class="media-heading">Tin Tức:</h4>
                            <p><marquee><img src="/img/chay.gif" width="50" height="50" > <script type="text/javascript" src="http://minh98pzo.hexat.com/loichao.js"></script> <img src="/img/khimoto.gif" width="50" height="50" ></marquee></p></center>
                            <div class="text-right">
                                <center><div class="fb-follow" data-href="https://www.facebook.com/VUTIENDUC.NET" data-layout="button_count" data-size="small" data-show-faces="true"></div> </center>


                            </div>
                        </div>
                </div><br>

<div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>Chức Năng VUTIENDUC.NET</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link ui-sortable">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                        <div class="tabs-container">
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab-1" data-toggle="tab" aria-expanded="true"><i class="zmdi zmdi-facebook-box"></i>BOT</a></li>
                            <li class=""><a data-toggle="tab" href="#tab-2" aria-expanded="false">AUTO</a></li>
                            <li class=""><a data-toggle="tab" href="#tab-3" aria-expanded="false">BOM</a></li>
                            <li class=""><a data-toggle="tab" href="#tab-4" aria-expanded="false">SUPPORT</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="tab-1" class="tab-pane active">
                                <div class="panel-body">

                               <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>BotLike</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=botlike">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot CMT</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=cm">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot Cmt Tự Chọn</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=botCommentRandom">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot Ex Like</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=exlike">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                        </div>

                               <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-heart" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot Ex Love</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=exlove">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot Đăng Stt Tùy Ý</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=BotUpdateStt">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot Đăng Stt Tự Động</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=botSttRandom">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot CNN Tự Động Đăng Wall</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=BotCNN">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                        </div>

   <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Open Beta</div>
                                        <div>Bot Reactions</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=botReactions">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot CMT Vui</div>
                                    </div>
                                </div>
                            </div>
                            <a href="?act=cm2">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot Poke</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=botPoke">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Bot Tương Tác Sao Vàng</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=botcmtSV">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                        </div>

                                </div>
                            </div>

                            <div id="tab-2" class="tab-pane">
                                <div class="panel-body">
                                    
                               <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>AuToLike</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=autolike">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>AuToSub</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=autosub">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>AuTo Cmt</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=autocmt">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Auto Copy Status</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=AutoCopyStt">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                        </div>

                               <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>AuTo Add Friends</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=AutoAddFriend">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>AuTo Confirm</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=AutoConfirm">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>AuTo Post Wall Friends</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=AutoPostFr">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Auto Post Group</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=AutoPostGroup">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                        </div>

                               <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>AuTo Post Page</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=AutoPostPage">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>AuTo Chấp Nhận Kết Bạn</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=AutoConfirm">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Auto Xóa Stt</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=DelStt">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Auto UnLike Page</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=UnLikeFanpage">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                        </div>

                            </div>
                        </div>

                        <div id="tab-3" class="tab-pane">
                                <div class="panel-body">

 <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Boom CMT</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=bomComment">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Boom Like</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=bomLike">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-comments" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Boom Wall</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=bomWall">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

<div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>Boom Cảm Xúc</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=baocamxuc">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                        </div>

                               <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-thumbs-o-up" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Free</div>
                                        <div>ĐAng UpDate</div>
                                    </div>
                                </div>
                            </div>
                            <a href="/?act=exlove">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

                            </div>
                        </div>

<div id="tab-4" class="tab-pane">
<div class="panel-body">
<div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
<i class="fa fa-phone" style="font-size:40px" aria-hidden="true"></i>  
                                </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">ConTact</div>
                                        <div>Liên Hệ Admin</div>
                                    </div>
                                </div>
                            </div>
                            <a href="https://www.facebook.com/messages/VUTIENDUC.NET/">
                                <div class="panel-footer">
                                    <span class="pull-left">Sử Dụng</span>
                                    <span class="pull-right"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

                            </div>
                        </div>

                    </div>
                        </div>
                    </div>
                </div>
  </div>



  ';

 }


?>