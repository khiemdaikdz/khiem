<script type="text/javascript">
function done()
	{
	$("#bodyupcmt").hide();
	$("#thongbao").show();
	}
</script>
<section class="content">

      <div class="row">
        <div class="col-md-3">
<div class="panel panel-info">
<div class="panel-heading ui-draggable-handle">
                        <h3 class="panel-title">Cá Nhân</h3>
                    </div>

    <!-- Main content -->
          <?php
		  print'
		   
         <!-- Thông Tin Member-->
         <div class="box box-primary">
            <div class="box-body box-profile">
<center>
<img class="profile-user-img img-responsive img-circle animated tada" src="https://graph.facebook.com/'.$_SESSION['id'].'/picture?width=150&height=150" alt="User profile picture"></center><br>

              <h3 class="profile-username text-center"><img src="http://r19.imgfast.net/users/1917/44/55/56/avatars/1-80.gif"> '.$_SESSION['name'].' <img src="http://r19.imgfast.net/users/1917/44/55/56/avatars/1-80.gif"></h3>

<center><span class="mfsl fcb"><span class="label label-success"><i class="fa fa-heart"></i> MEMBER CHẤT <i class="fa fa-heart"></i></span></span></center><br/>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b><i class="fa fa-envelope-o" aria-hidden="true"></i> Email:</b> <b><a class="pull-right"><span class="pull-right badge bg-aqua">'.$_SESSION['email'].'</b></span></a>
                </li>
                <li class="list-group-item">
                  <b><i class="fa fa-facebook-square" aria-hidden="true"></i> Profile ID:</b> <b><a class="pull-right"><span class="pull-right badge bg-green">'.$_SESSION['id'].'</b></span></a>
                </li>
        <li class="list-group-item">
                  <b><i class="fa fa-venus-mars" aria-hidden="true"></i> Giới Tính:</b> <b><a class="pull-right"><span class="pull-right badge bg-red">'.$_SESSION['gender'].'</b></span></a>
                </li>
                <li class="list-group-item">
                  <b><i class="fa fa-birthday-cake" aria-hidden="true"></i> Ngày Sinh:</b> <b><a class="pull-right"><span class="pull-right badge bg-purple">'.$_SESSION['birthday'].'</b></span></a>
                </li>
              </ul>
            <div class="panel-footer">
            </div>
          </div>  </div>  </div>     </div>
        <!-- /.kết thúc thông tin member-->';?>
 


      <div class="col-md-9">   <div class="panel panel-colorful">
<div class="panel-heading ui-draggable-handle">
                        <h3 class="panel-title">Auto Delete STT </h3>
                    </div>
<div class="panel-body">
            <div class="tab-content">
              <div class="active tab-pane" id="menu">
                <!-- Post -->
                <div id="bodyupcmt" class="post">

		<form action="/done/del.php" method="POST">	

<input type="hidden" name="access_token" class="form-control" autofocus="" value="<? echo $_SESSION['access_token'];?>"required="">	


  <label>        Nhập Số Lượng </label>

<input type="text" name="soluong" class="form-control" value="" placeholder="Số Lượng Stt Tỉ Lệ Thuận Với Tốc Độ Delete Stt...!!!" autofocus="" required="">	
<br/>
<span class="input-group-btn">
	<center>	<button type="submit" name="submit" onClick="done()" class="btn btn-primary">
						<span id="btn-click">
						<span class="glyphicon glyphicon-transfer"></span> Delete Status
						</span>
				</button>			</center>			</span>
		</div>			<br>

</form>
		</div>			

<div id="thongbao" style="display: none;"><div class="alert alert-danger">Trạng Thái: <span class="glyphicon glyphicon-refresh gly-animate"></span>  Đang Thực Hiện Quá Trình Delete Status...!!!
</font></div>

</section></section>
	
   
	<!-- ============================ End ============================ -->
    </div>