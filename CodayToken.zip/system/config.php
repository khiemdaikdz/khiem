<?php
$host = "127.3.236.2:3306";

$username = "riotlike_khiem";

$password = "01643850407";

$dbname = "riotlike_khiem";



$connection = mysql_connect($host,$username,$password);

if (!$connection)

{

die('Could not connect: ' . mysql_error());

}

mysql_select_db($dbname) or die(mysql_error());

mysql_query("SET NAMES utf8");
?>
