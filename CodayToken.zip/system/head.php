<?php
session_start();
error_reporting(0);
$act = $_GET['act'];
?>
<?php
//include 'banip.php';  
//include_once("analyticstracking.php")
?>
<!DOCTYPE html>
<!-- Ken -->
<html lang="vi">
<head>
	<meta charset="UTF-8">
	<meta name="description" content="Hack Like - Bot Like - Auto Like - Ex Like - Tools Facebook - Auto Sub - Auto Share - Auto Comment - RIOTLIKE.GA" />
        <meta name="keywords" content="hack like facebook, auto like facebook , Bot like ex, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack comment, tools facebook" />          
	<meta name="Classification" content="hack like facebook, auto like facebook , Bot like ex, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack comment, tools facebook" />
	<meta name="page-topic" content="hack like facebook, auto like facebook , Bot like ex, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack comment, tools facebook" />
	<link rel="shortcut icon" href="./img/vutienduc.png" />
	<meta name="author" content="RIOTLIKE.GA" />
	<meta name="generator" content="RIOTLIKE.GA" />
	<meta name="copyright" content="RIOTLIKE.GA" />
	<meta name="rating" content="general" />
	<meta name="geo.region" content="VN-SG" />
	<meta name="geo.placename" content="QUANG NGAI, Viet Nam" />
	<meta name="DC.title" content="Auto Like Facebook, Hack Like Facebook, Bot Like FaceBook, Auto Sub Facebook" />
	<meta name="DC.description" content="Hack like facebook, auto like facebook, trang web tang like facebook  nhanh, auto sub facebook, auto comment facebook " />
	<meta name="DC.subject" content="Hack Like, Auto Like, Hack Sub, Auto Theo Dõi, Auto Bình Luận" />
	<meta name="DC.language" scheme="UTF-8" content="vi" />
	<meta name="robots" content="index, all, follow" />
	<meta name="revisit-After" content="1 days" />
	<meta name="rating" content="general" />
                    <meta property="og:image" content="./img/vutienduc.png"/>
                    <meta name="description" content="RIOTLIKE.GA Là Một Công Cụ Đắc Lực Giúp Bạn Quản Lí Tài Khoản Facebook Một Cách Tự Động Hóa. Bao Gồm Các Chức Năng Như: Bot Like, Bot Auto Comment, Bot Ex Like, Bom Like, Bom Cmt, Bom Wall, Bot Auto Reply Inbox, Bot Auto Update Stt, Bot Delete Stt, Bot Auto Confirm Friend Request, Bot Auto Poke, Auto Like, Auto Share, Auto Sub Facebook..."/>
	<link rel="author" href="https://plus.google.com/112026050071690801079" />
	<link rel="publisher" href="https://plus.google.com/112026050071690801079"/>
	<link rel="canonical" href="http://RIOTLIKE.GA" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="./img/vutienduc.png"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">  
    <link href="kenso1/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="kenso1/css/plugins/toastr/toastr.min.css" rel="stylesheet" type="text/css">
    <link href="kenso1/css/animate.css" rel="stylesheet" type="text/css">
    <link href="kenso1/css/style3.css" rel="stylesheet" type="text/css">
    <link href="http://github.danielcardoso.net/load-awesome/assets/loaders.css" rel="stylesheet" type="text/css">
<title>Hack Like - Auto Like - Bot Like - Ex Like - Reation - RIOTLIKE.GA</title>
</head>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '825555470914751',
      xfbml      : true,
      version    : 'v2.7'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
<!--
 

-->                                                              
                                                                 
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">

<?php
                        if($_SESSION['name'])
                            {
                        ?>
                        <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="https://graph.facebook.com/<?php echo $_SESSION[id]; ?>/picture" />
                             </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $_SESSION[name]; ?></strong>
                             </span> <span class="text-muted text-xs block">Chào Bạn !<b class="caret"></b></span> </span>
                            </a>
<?php
                        }
                    else
                        {
                ?>
<div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="https://3.bp.blogspot.com/-YeiPxfU0uTg/WClaTMtNOSI/AAAAAAAAAVQ/jFMXZGUln-8AnLWEEsFK5Uh_F5Nkq8i8QCLcB/s1600/995380_206634156382698_7843637339315154706_n.jpg" />
                             </span>
<a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Administrator</strong>
                             </span> <span class="text-muted text-xs block">Chào Khách !<b class="caret"></b></span> </span>
                            </a>
                <? } ?>
<?php
                        if($_SESSION['id'])
                            {
                        ?>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="https://www.facebook.com/<?php echo $_SESSION[id]; ?>/">Profile</a></li>
                                <li><a href="https://www.facebook.com/<?php echo $_SESSION[id]; ?>/allactivity/">Nhật Ký Hoạt Động</a></li>
                                <li><a id='vutienanh'"></a></li>
                                <li class="divider"></li>
                                <li><a href="logout.php">Logout</a></li>
                            </ul>
                        </div>
<?php
                        }
                    else
                        {
                ?>
<ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="https://www.facebook.com/KHIEMDAIK.DZ">Admin</a></li>

                            </ul>
                        </div>
                                                <? } ?>

                        <div class="logo-element">
                            KEN
                        </div>
                    </li>
                    <li class="active">
                        <a href="index.php"><i class="fa fa-home fa-spin"></i><span class="nav-label">Trang Chủ</span></a>
                    </li>

                    <li>
                        <a href="huongdan.php"><i class="fa fa-life-bouy"></i><span class="nav-label">Hướng Dẫn</span></a>
                    </li>
<li>
                        <a href="about.php"><i class="fa fa-magic"></i><span class="nav-label">About</span></a>
                    </li>
                    <li>
                        <a href="terms.php"><i class="fa fa-lock"></i><span class="nav-label">Terms</span></a>
                    </li>
<li>
                        <a href="vip.php"><i class="fa fa-diamond"></i><span class="nav-label">Mua VIP</span></a>
                    </li>
                    <li>
                        <a href="privacy.php"><i class="fa fa-meh-o"></i><span class="nav-label">Privacy</span></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-group"></i> <span class="nav-label">MeNu Bot</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="?act=botlike">Bot Like</a></li>
                            <li><a href="?act=cm">Bot Comment</a></li>
                            <li><a href="?act=exlike">Bot Ex Like</a></li>
                            <li><a href="?act=exlove">Bot Ex Love</a></li>
                            <li><a href="?act=botCommentRandom">Bot Comment Tùy Ý</a></li>
                            <li><a href="?act=botInboxRandom">Bot InBox Tùy Ý</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-star-o"></i> <span class="nav-label">Menu Auto</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="#"><span class="nav-label">Auto Chức Năng Hành Động</span> <span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level collapse">
                                    <li><a href="?act=autolike">Auto Like</a></li>
                                    <li><a href="?act=autosub">Auto Sub</a></li>
                                    <li><a href="?act=autocmt">Auto Comment</a></li>
                                    <li><a href="?act=autoshare">Auto Share</a></li>
                                    <li><a href="?act=AutoAddFriend">Auto Friends</a></li>
                                </ul>
                            </li>
                            <li><a href="#"><span class="nav-label fa-spin">Auto Tiện Ích</span> <span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level collapse">
                                    <li><a href="?act=AutoPostGroup">Auto Post Group</a></li>
                                    <li><a href="?act=AutoPostPage">Auto Post Page</a></li>
                                    <li><a href="?act=AutoPostFr">Auto Post Wall Friends</a></li>
                                    <li><a href="?act=AutoConfirm">Auto Confirm</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-fa fa-bomb"></i> <span class="nav-label">Menu Boom</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                                    <li><a href="?act=bomLike">Boom Like</a></li>
                                    <li><a href="?act=bomComment">Boom Comment</a></li>
                                    <li><a href="?act=baocamxuc">Boom Cảm Xúc</a></li>
                                    <li><a href="?act=bomWall">Boom Wall</a></li>
                                    </ul>
                    </li>
                    <li>
                           
                        <a href="#"><i class="fa fa-cogs"></i> <span class="nav-label">Tools</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                                    <li><a href="checktoken.html"><i class="fa fa-check"></i>Check Access Token</a></li>
                                    <li><a href="loc-acc.html"><i class="fa fa-star"></i>Lọc Account Trùng</a></li>
                                    <li><a href="loc-token.html"><i class="fa fa-database"></i>Lọc Access Token</a></li>
  <li><a href="#kenso1" data-target="#popup_id" data-toggle="modal" title="Get ID"><i class="fa fa-edit"></i> <span class="nav-label">Lấy ID Status / Ảnh...</span></a></li>                                    <li><a href="LiveFb"><i class="fa fa-film"></i>Live Stream FB</a></li>
                                    </ul>
                    </li>
<li>
                           
                        <a href="#"><i class="fa fa-phone"></i> <span class="nav-label">ConTacts</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                                    <li><a href="https://www.facebook.com/khiemdaik.dz"><i class="fa fa-user"></i>ProFile</a></li>
                                    <li><a href="https://www.facebook.com/messages/khiemdaik.dz"><i class="fa fa-code"></i>InBox</a></li>
                                    </ul>
                    </li>

                                   <li>
                        <a href="#"><i class="fa fa-paper-plane"></i> <span class="nav-label">Liên Kết</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="http://RIOTLIKE.GA/"><i class="fa fa-star"></i>RIOTLIKE.GA</a></li>             
                            <li><a href="https://www.facebook.com/messages/KHIEMDAIK.DZ"><i class="fa fa-phone"></i>Chéo InBox Admin</a></li>
                        </ul>
                    </li>

                        <ul class="nav nav-second-level collapse">
<a href="http://duatop.vina4u.pro/counter/domain.php?id=254"><img src="http://duatop.vina4u.pro/img.php?254"/></a>
             </ul>
                    </li>
                </ul>
                    </div>

        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                        <form role="search" class="navbar-form-custom" action="search_results.html">
                            <div class="form-group">
                                <input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
                            </div>
                        </form>
                    </div>
<?php
                        if($_SESSION['name'])
                            {
                        ?>
                    <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <span class="m-r-sm text-muted welcome-message">WelCome ! <?php echo $_SESSION[name]; ?></span>
                        </li>
                        <li>
                            <a href="logout.php">
                                <i class="fa fa-sign-out"></i>Đăng Xuất
                            </a>
                        </li>
<?php
                        }
                    else
                        {
                ?>
 <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <span class="m-r-sm text-muted welcome-message">Chào Khách !</span>
                        </li>
                                          <? } ?>
  
                        <li>
                            <a class="right-sidebar-toggle">
                                <i class="fa fa-tasks"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="row">
                
      
