<?php

if(!$_SESSION['id']){ print '<script>top.location.href="index.php";</script>';
exit;
}


viewChat();

if($_POST[message]){
$message=$_POST[message];
$xxx=array('dm','đm','Dm','Đm','dcm','đcm','vl','fuck','dit','djt','địt','lồn','loz','djt',);
foreach($xxx as $xn=> $mades){
if(ereg($mades,strtolower($message))){
$madesu=true;
}
}

if($madesu){
print '<script>alert("Không nói bậy!");</script>';
}else{
saveChat($_SESSION['id'],$_SESSION['name'],$_POST[message]); 
print '<meta http-equiv="refresh" content="0;url=/?n"/>';
}
}


function saveChat($id,$name,$message){
$set_jam=7; 
$tang =gmdate('d F Y',time()+($set_jam*3600));
$jame =gmdate('H:i',time()+($set_jam*3600));
$tme=gmdate('Y',time()+($set_jam*3600));
$hrs=gmdate('z',time()+($set_jam*3600));
$jum=(($tme-1)*365)
+(int)(($tme-1)/4)+$hrs;
$di=7*(int)($jum/7);
$dino=$jum-$di;
$pas=5*(int)($jum/5);
$pasar=$jum-$pas;
$dino=str_replace('6','Đăng',$dino);
$dino=str_replace('0','Đăng',$dino);
$dino=str_replace('1','Đăng',$dino);
$dino=str_replace('2','Đăng',$dino);
$dino=str_replace('3','Đăng',$dino);
$dino=str_replace('4','Đăng',$dino);
$dino=str_replace('5','lúc`at',$dino);
$pasar=str_replace('4','lúc',$pasar);
$pasar=str_replace('0','lúc',$pasar);
$pasar=str_replace('1','lúc',$pasar);
$pasar=str_replace('2','lúc',$pasar);
$pasar=str_replace('3','lúc',$pasar);
$date=''.$dino.' '.$pasar.'  '.$tang.' '.$jame.' ';
$data[] = array(
'id' => $id,
'name' => $name,
'message' => $message,
'date' => $date,
);

if(file_exists('tmpChat.txt')){
$view = json_decode(file_get_contents('tmpChat.txt'),true);}else{ $view = array();}
$x=json_encode(array_merge($data,$view));
$f = fopen('tmpChat.txt','w');
fwrite($f,$x);
fclose($f);
}

function viewChat(){
if(file_exists('tmpChat.txt')){ $data=json_decode(file_get_contents('tmpChat.txt'),true);}else{$data=array();}
if($_GET[n]){
$a=htmlspecialchars($_GET[n]);
$b=$a+6;
}else{
$a=0;
$b=6;
}
if($a < count($data) -6){
$next='<a class="fcs" href="/?n='.$b.'"> Sau>> </a>';
}
if($a > 1){
$prev='<a class="fcs" href="/?n='.($a-6).'"> << Trước</a>';
} if(file_exists('/DuySexy/news')){ $news=file_get_contents('/DuySexy/news'); }else{ $news= ' ';}
for($i=$a;$i<$b;$i++){
if($data[$i]){   
$data[$i][name] = str_replace('Vũ Tiến Anh','<font face="Bambino"><span style="background: transparent url(http://i106.photobucket.com/albums/m280/YukioKenshin/chopnhay.gif) repeat scroll 0%; -moz-background-clip: initial; -moz-background-origin: initial; -moz-background-inline-policy: initial; color: white; text-shadow: red 0pt 0pt 0.3em, red 0pt 1pt 0.3em;"><img src="http://i40.servimg.com/u/f40/17/60/05/62/310.gif"> VTADZ </span><span style="background: transparent url(http://i106.photobucket.com/albums/m280/YukioKenshin/chopnhay.gif) repeat scroll 0%; -moz-background-clip: initial; -moz-background-origin: initial; -moz-background-inline-policy: initial; color: white; text-shadow: green 0pt 0pt 0.3em, green 0pt 1pt 0.3em;"></span></font>

print '

              <div class="item">
                <img src="http://graph.facebook.com/'.$data[$i][id].'/picture" alt="user image" class="online">
                <p class="message">
                  <a href="#" class="name">
                    <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> '.$data[$i][date].'</small>
					'.$data[$i][name].'
                 </a>
                '.nl2br(stripslashes(htmlspecialchars($data[$i][message]))).'
				</p>        
              </div>
';
}
}
print'
<div class="box-footer">
              <form method="post" action="">
			  <div class="input-group">
                <input class="form-control" placeholder="Nhập Nội Dung Vào Đây" name="message" required="">

                <div class="input-group-btn">
                  <button type="submit" class="btn btn-success">Sent <i class="fa fa-paper-plane-o"></i></button>
                </div>
              </div>
            </div>
          </form>
		  </div>     

';

print '</div></div></div>';
}


?>