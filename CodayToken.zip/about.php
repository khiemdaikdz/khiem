<?php
include 'system/head.php';
print '<div class="wrapper wrapper-content animated fadeInRight">
<div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>About - RIOTLIKE.GA</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header">
             

              <b><h3 class="box-title">About</h3><b><hr>
            </div>
            <div class="box-body pad table-responsive">
<p class="text-muted well well-sm no-shadow" style="margin-top: 1px;">
<b>
<font size="4px">Tôi là 1 Newbie trong lớp Dev trẻ. StarVip.InFO được xây dựng trên nền bootstrap và php. Nó có nhiều tính năng công cụ tiện ích, sở hữu một tốc độ khá nhanh và khá chuyên nghiệp.Mọi ý kiến đóng góp và tài trợ chúng tôi đều đánh giá cao.
</font>
</b>
</p>

<p class="text-muted well well-sm no-shadow" style="margin-top: 6px;">
<b>
<font size="4px">Nó được lập trình để giúp những người sử dụng Facebook được nhiều like trên bài viết mà không cần phải đi xin like. Chức năng RIOTLIKE.GA hoàn toàn miễn phí và chúng tôi không bao giờ yêu cầu người dùng trả phí để có thể sử dụng. Chúng tôi cung cấp các dịch vụ tốt nhất của Facebook hoàn toàn miễn phí!
</font>
</b>
</p>
</div></div></div>
</section>
</div></div></div>

     ';
	include'system/foot.php';
	?>