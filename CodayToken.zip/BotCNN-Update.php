<?php
include 'config.php';
function mbalek($x){
print '<meta http-equiv="refresh" content="0;url='.$x.'"/>';
}

if(isset($_POST['idcnn']))
{
mysql_query("DELETE FROM cnn WHERE idcnn = '".$_POST['idcnn']."' ");
mbalek('/?act=BotCNN&i='.urlencode('Xoa thanh cong !!!'));
}
if(isset($_POST['update'])){
mysql_query("UPDATE `cnn` 

SET `token` ='".$_POST['token']."'

WHERE `id` = '".$_POST['id']."' ");
mbalek('/?act=BotCNN&i='.urlencode('Cap nhat thanh cong !!!'));
}

?>