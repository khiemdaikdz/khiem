<?php
include 'system/head.php';
print '<div class="wrapper wrapper-content animated fadeInRight">

    <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Terms - RIOTLIKE.GA</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">

   <section class="content">

      <div class="row">
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header">
             

              <b><h3 class="box-title">Privacy</h3><b><hr>
            </div>
            <div class="box-body pad table-responsive">
	  
<p class="text-muted well well-sm no-shadow" style="margin-top: 6px;">
           <b><font size="5px">Our system is FREE.</font><br>
<font size="3px">
Therefore, we must maintain active our servers and then you agree that when using the website will be like and comment on the posts of unknown people automatically. Also, we can use your account to post content on Facebook if we want.
          </font></p></b>
		<p class="text-muted well well-sm no-shadow" style="margin-top: 8px;">
           <b><font size="5px">Third Party Websites</font><br>
<font size="3px">
Users may find advertising or other content on our Site that link to the sites and services of our partners, suppliers, advertisers, sponsors, licensors and other third parties. We do not control the content or links that appear on these sites and are not responsible for the practices employed by websites linked to or from our Site. In addition, these sites or services, including their content and links, may be constantly changing. These sites and services may have their own privacy policies and customer service policies. Browsing and interaction on any other website, including websites which have a link to our Site, is subject to that website is own terms and policies.
          </font></p></b>
		  <p class="text-muted well well-sm no-shadow" style="margin-top: 8px;">
           <b><font size="5px">Cookie DoubleClick DART</font><br>
<font size="3px">
Google, as a provider of income to our site, use cookies to serve ads on our website; With the DART cookie, Google can display ads based on visits to the reader to other sites on the Internet ads; Users can disable the DART cookie by the privacy policy of the content network and Google ads.
          </font></p></b>
		  <p class="text-muted well well-sm no-shadow" style="margin-top: 8px;">
           <b><font size="5px">Contacting us</font><br>
<font size="3px">
If you have any questions about this, the practices of this site, or your dealings with this site, please contact us at: admin@starvip.info This document was last updated on August 14, 2016. 

          </font></p></b>
    </section>
</div></div>';
include 'system/foot.php';
?>