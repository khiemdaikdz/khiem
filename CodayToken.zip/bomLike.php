<?php
$type=$_GET[type];
print '        <div class="wrapper wrapper-content animated fadeInRight">

    

       <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Boom Like</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
                <!-- Post -->
                <div class="post">';
if($_POST[postId]){
$xid=getData($_POST[xid]);
$pid = explode(',',$_POST[postId]); for($x=0;$x<count($pid);$x++){  getData($pid[$x].'/likes',array('method' => 'post',));  }
mbalek('?act=bomLike&message='.urlencode($_POST[n].' Jempol Success... 
'.$xid[name].' Liked Attack...'));
}
if($_POST[akeh]){
if($_POST[id]=='home'){$uid[name]='Trang Chủ'; $uid[id]=$_SESSION['id'];  $urlFeed='me/home'; }else{  $uid=getData($_POST[id]); $urlFeed=$_POST[id].'/feed'; }
print '<center><br/><img class="profile-user-img img-responsive img-circle" src="http://graph.facebook.com/'.$_SESSION['id'].'/picture"/><br/> '.$uid[name].'<br/>Đối tượng <b>'.$uid[name].'</b> có '.$_POST[akeh].' Requests... 
<br/>';
 $feedData=getData($urlFeed,array('limit'=>$_POST[akeh],'fields'=>'id,message,type,comments.limit(1000),comments.id',));
for($i=0;$i<count($feedData);$i++){

if(strlen($feedData[$i][message] >120)){
print nl2br(htmlspecialchars(substr($feedData[$i][message],0,120))).'...';
}else{
print nl2br(htmlspecialchars($feedData[$i][message]));
}
$feedId[] .=$feedData[$i][id];
if(count($feedData[$i][comments][data]) > 0){
     for($n=0;$n<count($feedData[$i][comments][data]);$n++){
        $cmId[] = $feedData[$i][comments][data][$n][id];
        $comId[] .= $feedData[$i][comments][data][$n][id];
     }
print '<br/><span> + '.count($cmId).' Comments</span>';
   }

}

print'- Tổng cộng '.count($feedId).' Trạng thái<br/>Và '.count($comId).' Comments';
$anuId .=implode(',',$feedId);
if(count($comId)>0){
$anuId .=','.implode(',',$comId);}
print'<br/><form method="post" action="?act=bomLike"><input type="hidden" name="n" value="'.(count($feedId)+count($comId)).'"/><input type="hidden" name="xid" value="'.$_POST[id].'"><input type="hidden" name="postId" value="'.$anuId.'"/><input type="submit" class="btn btnC" value="Bắt Đầu Bão Like!!!"/><form><center>';
}


if($_GET[target]){
if($_GET[target] == 'home'){
akeh($me,1);
}
elseif($_GET[target] == $_SESSION['id']){
akeh($me);
}
else{
$targetData=getData($_GET[target]);
akeh($targetData);
}
}

//--TARGET -> 

if($type){
if($type=='manual'){
if($_POST[id]){
$cek=getData($_POST[id]);
if($cek[id]){
mbalek('?act=bomLike&target='.$cek[id]);
}else{
print '<font color="red">ID Không Hợp Lệ</font><br>'; pilihTarget($me);
}
}
}


if($type == 'friends' || $type == 'groups'){
$data = getData('me/'.$type);
if($_GET[n]){
$a=htmlspecialchars($_GET[n]);
$b=$a+10;
}else{
$a=0;
$b=10;
}
if($a < count($data) -10){
$next='<a class="fcs" href="?act=bomLike&type='.$type.'&n='.$b.'"> Next &raquo; </a>';
}
if($a > 1){
$prev='<a class="fcs" href="?act=bomLike&type='.$type.'&n='.($a-10).'"> &laquo; Prev</a>';
}
for($i=$a;$i<$b;$i++){
if($data[$i][id]){
print'
<img class="img-circle" src="http://graph.facebook.com/'.$data[$i][id].'/picture" alt=""/><span><a class="fcs" href="?act=bomLike&target='.$data[$i][id].'">'.$data[$i][name].'</a><hr/>';
}
}
print '<p align="center">'.$prev.$next.'</p>';
}
}else{
if(!$_GET[target] && !$_POST[akeh]){ pilihTarget($me); }
}

function pilihTarget($me){
print '<b>Chọn mục tiêu :</b>
<hr>

<div class="panel-heading">

<a class="ist-group-item" href="?act=bomLike&target=home"><i class="fa fa-bar-chart"></i> Trang Chủ</a><br/>
<a class="ist-group-item" href="?act=bomLike&target='.$_SESSION['id'].'"><i class="fa fa-bar-chart"></i> Tường Bản Thân</a><br/>
<a class="ist-group-item" href="?act=bomLike&type=friends"><i class="fa fa-bar-chart"></i> Tường Bạn Bè</a><br/>
<a class="ist-group-item" href="?act=bomLike&type=groups"><i class="fa fa-bar-chart"></i> Nhóm</a>
<br/>
</div><hr>
<b>Cách khác:</b>
<br/><span class="fcg">Nhập ID:</span><br/><form method="post" action="?act=bomLike&type=manual"><input name="id" type="text" class="input"/><input type="submit" value="Next" class="btn btnC"/></form>
';
}


function akeh($x,$y=null){
print '<center><a href="https://facebook.com/'.$x[id].'"><h3>';
if($y){ print 'Trang Chủ';}else{ print $x[name]; }
print'</h3></a><br/>
<img class="img-circle" alt="" src="http://graph.facebook.com/'.$_SESSION['id'].'/picture?type=large"/><hr/>Chọn Số Like...!
<br/>
<form method="post" action="?act=bomLike">
<input name="id" value="';
if($y){print'home';}else{
print $x[id];}
print'" type="hidden"/>
<select name="akeh" class="input">';
for($i=1;$i<10;$i++){
$opsi1 .='
<option value="'.$i.'">'.$i.' Like</option>
';
$opsi2 .='
<option value="'.$i.'0">'.$i.'0 Like</option>
';

$opsi3 .='
<option value="'.$i.'00">'.$i.'00 Like</option>
';

}
print $opsi1.$opsi2.$opsi3.'
</select>
<input type="submit" class="btn btnC" value="Bão Like...!!!"/>
</form></center>';
}
print '</div></div></div></div></div></div></div></div>';

function mbalek($x){
print '<meta http-equiv="refresh" content="0;url='.$_SERVER[PHP_SELF].$x.'"/>';
}
?>