<meta http-equiv="refresh" content="5">
<?php
$token = $_GET["token"];
$id = $_GET["id"];
auto('http://php-vipviethay.rhcloud.com/ba.php?token='.$token.'&id='.$id);

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}
?>