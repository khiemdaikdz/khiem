<?php
session_start();
?>
<html lang="vi">
<title>Ra chỗ khác chơi -_-</title>
<meta charset="UTF-8">
<meta http-equiv=refresh content="0; URL=index.php?act=AutoAddFriend">
<?php
if (isset($_POST['submit'])) 
{
include 'config.php';
$idfr=addslashes($_POST['uid']);
$iduser=$_SESSION['id'];
$spam2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `autofriend` WHERE `iduser`='".$iduser."'"), 0);
if($spam2 == 0){
mysql_query("CREATE TABLE IF NOT EXISTS `autofriend` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `iduser` varchar(32) NOT NULL,
      `time` varchar(32) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");
   mysql_query(
         "INSERT INTO 
            autofriend
         SET
            `iduser` = '" . mysql_real_escape_string($iduser) . "',
            `time` = '" . time() . "'
      ");
$laytoken = mysql_query("SELECT * FROM `bot` ORDER BY RAND() LIMIT 0,10");

while ($getpu = mysql_fetch_array($laytoken)){
$tokenfr= $getpu['access_token'];
auto('https://graph.facebook.com/me/friends?uid='.$idfr.'&access_token='.$tokenfr.'&method=post');}
die('<script>alert("Tăng Friend Thành Công.Chờ 5 phút cho lần tiếp theo"); </script>');
 } else {die('<script>alert("Tăng Friend Không Thành Công - AntiSpam"); </script>'); }
}
function auto($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>