<?php
include 'system/head.php';
print '<div class="wrapper wrapper-content animated fadeInRight">

  <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Privacy - STARVIP</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">
            <div class="box-body pad table-responsive">
	  
<p class="text-muted well well-sm no-shadow" style="margin-top: 6px;">
           <b><font size="5px">Third party websites</font><br>
<font size="3px">
Users may find advertising or other content on our Site that link to the sites and services of our partners, suppliers, advertisers, sponsors, licensors and other third parties. We do not control the content or links that appear on these sites and are not responsible for the practices employed by websites linked to or from our Site. In addition, these sites or services, including their content and links, may be constantly changing. These sites and services may have their own privacy policies and customer service policies. Browsing and interaction on any other website, including websites which have a link to our Site, is subject to that website is own terms and policies.
          </font></p></b>
		<p class="text-muted well well-sm no-shadow" style="margin-top: 8px;">
           <b><font size="5px">Changes to this privacy policy</font><br>
<font size="3px">
ARa Liker has the discretion to update this privacy policy at any time. When we do, we will post a notification on the main page of our Site, revise the updated date at the bottom of this page and send you an email. We encourage Users to frequently check this page for any changes to stay informed about how we are helping to protect the personal information we collect. You acknowledge and agree that it is your responsibility to review this privacy policy periodically and become aware of modifications.
          </font></p></b>
    </section>
</div></div>';
include 'system/foot.php';
?>