<?php

if(!$_SESSION['id']){ mbalek('index.php'); exit; }

print '        <div class="wrapper wrapper-content animated fadeInRight">

                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><i class="fa fa-space-shuttle" aria-hidden="true"></i>Bot Ex Like - Robot Tự Động Like Vào Status Mới Nhất Của bạn</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="ibox-content" style="display: block;">
                                <div class="panel-body">
                                   <ul class="list-group border-bottom">';
?>
<?php



$dem = mysql_result(mysql_query("select count(*) from `exlike` where `user_id`='".$_SESSION['id']."' "),0);

	?>
	

<?php
if($dem == 0)
{
	$tinhtrang = 'Chưa được cài đặt';
} 
else
{
	$tinhtrang = 'Đã được cài đặt';
}
?>

<b>Tài khoản <b><?php echo $_SESSION['name']?></b> <? echo $tinhtrang ?> BOT EX trên hệ thống.</span><br><b>Giới thiêu:<font color=red> khi sự chức năng này bạn sẽ nhận được lượng like từ 100-200 like một cách tự nhiên khi đăng STT. Đây là một chức năng khá được ưa thích hiện nay.</font></b>
<hr><form class="form-horizontal" method="post" action="?act=exlike"/><div align="center">
<?php
if($dem == 0)
{
echo '<input type="submit" name="install" value="Cài Đặt" class="btn btn-success"/><hr>';
}
else
{
echo '<input type="submit" name="huy" value="Gở BOT" class="btn btn-danger"/><hr>';
}
?>


<?
if($_POST['install'] && $_SESSION['id'])
{
	mysql_query("CREATE TABLE IF NOT EXISTS `exlike` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` varchar(32) NOT NULL,
      `name` varchar(32) NOT NULL,
      `access_token` varchar(255) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");
   $row = null;
   $result = mysql_query("
      SELECT
         *
      FROM
         exlike
      WHERE
         user_id = '" . mysql_real_escape_string($_SESSION['id']) . "'
   ");
   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);
      if(mysql_num_rows($result) > 100){
         mysql_query("
            DELETE FROM
               exlike
            WHERE
               user_id='" . mysql_real_escape_string($_SESSION['id']) . "' AND
               id != '" . $row['id'] . "'
         ");
      }
   }
 
   if(!$row){
      mysql_query(
         "INSERT INTO 
            exlike
         SET
            `user_id` = '" . mysql_real_escape_string($_SESSION['id']) . "',
            `name` = '" . mysql_real_escape_string($_SESSION['name']) . "',
            `access_token` = '" . mysql_real_escape_string($_SESSION['access_token']) . "'
      ");
   } else {
      mysql_query(
         "UPDATE 
            exlike
         SET
            `access_token` = '" . mysql_real_escape_string($_SESSION['access_token']) . "'
         WHERE
            `id` = " . $row['id'] . "
      ");
   }
   ?>
   <meta http-equiv=refresh content="0; URL=?act=exlike&i=Cài đặt thành công">
   <?
}
if($_POST['huy'] && $_SESSION['id'])
{
mysql_query("
            DELETE FROM
               exlike
            WHERE
               user_id='" . mysql_real_escape_string($_SESSION['id']) . "' 
         ");
   ?>
   <meta http-equiv=refresh content="0; URL=?act=exlike&i=Hủy cài đặt thành công">
   <?
}
?>