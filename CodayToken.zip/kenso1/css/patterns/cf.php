<?php
$host = "127.3.236.2:3306";

$username = "adminup9UVIN";

$password = "ybt2Dgk6wYy8";

$dbname = "star";



$connection = mysql_connect($host,$username,$password);

if (!$connection)

{

die('Could not connect: ' . mysql_error());

}

mysql_select_db($dbname) or die(mysql_error());

mysql_query("SET NAMES utf8");
?>
