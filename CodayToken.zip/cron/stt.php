<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include'config.php';
date_default_timezone_set('Asia/Ho_Chi_Minh');
$ktgio=date('H');
$ktphut=date('i');
$int=intval($_GET['id']);
$sql=mysql_query("SELECT `id` FROM `stt` WHERE `id`='$int' ");
$row=mysql_fetch_assoc($sql);
$post = mysql_fetch_array(mysql_query("select * from `stt` WHERE  `id` = '$int' LIMIT 1"));
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `stt`"), 0);
$res = mysql_query("SELECT * FROM `stt` LIMIT $tong");
while ($post = mysql_fetch_array($res)){
$access_token = $post['access_token'];
$gio = $post['gio'];
$phut = $post['phut'];
$tatmo = $post['tatmo'];
if($tatmo == 1){
if($ktgio == $gio){
if($ktphut == $phut){
$noidung = $post['noidungstt'];
$status = array(
            'ðŸ‘‘ '.$noidung.' ðŸ† '
            ,            
            );
$message = $status[rand(0,count($status)-1)];
auto('https://graph.facebook.com/me/feed?access_token='.$access_token.'&message='.urlencode($message).'&method=post&subject=+');
  echo' Trạng Thái : <font color="blue"><b>'.$status.'</font></b><br/>';
}}}}
echo ' '.$ktgio.' - '.$ktphut.' ';
function auto($url){
   $ch=curl_init();
   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
   curl_setopt($ch,CURLOPT_URL,$url);
   $cx=curl_exec($ch);
  curl_close($ch);
  return($cx);
  }

?>

