<?php
include'config.php';
kenso1(''.$domain.'/cron/camxuc.php');
kenso1(''.$domain.'/cron/camxucex.php');
kenso1(''.$domain.'/cron/lk.php');
kenso1(''.$domain.'/cron/cm.php');
kenso1(''.$domain.'/cron/exlike.php');
kenso1(''.$domain.'/cron/lkvip.php');
kenso1(''.$domain.'/cron/stt.php');
kenso1(''.$domain.'/cron/ibrd.php');
kenso1(''.$domain.'/cron/cmtrd.php');
kenso1(''.$domain.'/cron/simsimi.php');
function kenso1($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>