

<?

include'config.php';
?>

<?
$int=intval($_GET['id']);
$sql=mysql_query("SELECT `id` FROM `exlike` WHERE `id`='$int' ");
$row=mysql_fetch_assoc($sql);
$post = mysql_fetch_array(mysql_query("select * from `exlike` WHERE  `id` = '$int' LIMIT 0,1"));
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `exlike`"), 0);
$res = mysql_query("SELECT * FROM `exlike` ORDER BY RAND() LIMIT 0,5");
while ($post = mysql_fetch_array($res)){
$result = mysql_query("SELECT * FROM exlike ORDER BY RAND() LIMIT 0,30");
if($result){
while($row = mysql_fetch_array($result))
  {
$access_token = $row[access_token];

$idchinh= $post['id'];
$idface= $post['user_id'];
if(!$idface){
mysql_query("DELETE FROM `exlike` WHERE `id` = $idchinh ");
}
//**Like**//
$puaru = auto('https://graph.facebook.com/'.$post['user_id'].'/feed?limit=1&access_token='.$access_token);
$arraykhanh = json_decode($puaru, true);
$puaruid = $arraykhanh[data][0][id];
$tachidkhanh = explode("_",$puaruid);
auto('https://graph.facebook.com/'.$puaruid.'/likes?method=post&access_token='.$access_token);

//**LikeEnd**//


}
}
}
function auto($url) {
   $ch = curl_init();
   curl_setopt_array($ch, array(
      CURLOPT_CONNECTTIMEOUT => 5,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_URL            => $url,
      )
   );
   $result = curl_exec($ch);
   curl_close($ch);
   return $result;
}
?>